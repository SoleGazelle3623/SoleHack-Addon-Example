package com.yourwebsitespace.solehack;

import com.yourwebsitespace.solehack.modules.combat.BedAura;
import com.yourwebsitespace.solehack.modules.combat.BedAuraConfigScreen;
import com.yourwebsitespace.solehack.modules.combat.CrystalAura;
import com.yourwebsitespace.solehack.modules.combat.CrystalAuraConfigScreen;
import com.yourwebsitespace.solehack.modules.misc.Proxy;
import com.yourwebsitespace.solehack.modules.misc.ProxyConfigScreen;
import com.yourwebsitespace.solehack.modules.render.CrystalColor;
import com.yourwebsitespace.solehack.modules.render.CrystalColorConfigScreen;
import com.yourwebsitespace.solehack.modules.render.HandView;
import com.yourwebsitespace.solehack.modules.render.HandViewConfigScreen;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ConfigScreen extends GuiScreen {
    private final GuiScreen parent;
    private Category selectedCategory = Category.COMBAT;
    private Module awaitingBind = null;

    // Search Box Components
    private GuiTextField searchField;
    private String searchQuery = "";

    public ConfigScreen(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public void func_73866_w_() {

        this.field_146292_n.clear();


        // Calculated horizontal margins to host all 5 category headers cleanly
        int tabWidth = 68;
        int startX = this.field_146294_l / 2 - (tabWidth * Category.values().length) / 2;
        int tabY = 25;
        Category[] categories = Category.values();

        for (int i = 0; i < categories.length; i++) {
            GuiButton tabButton = new GuiButton(100 + i, startX + i * tabWidth, tabY, tabWidth - 2, 20, capitalize(categories[i].name()));
            if (categories[i] == selectedCategory) {
                tabButton.field_146124_l = false;
            }
            this.field_146292_n.add(tabButton);
        }

        // Initialize our search text input bar field
        this.searchField = new GuiTextField(99, this.field_146289_q, this.field_146294_l / 2 - 100, 52, 200, 20);
        this.searchField.func_146203_f(32);
        this.searchField.func_146195_b(selectedCategory == Category.SEARCH);
        this.searchField.func_146180_a(searchQuery);

        addModuleButtons();
        this.field_146292_n.add(new GuiButton(999, this.field_146294_l / 2 - 100, this.field_146295_m - 30, 200, 20, "Done"));
    }

    private void addModuleButtons() {
        List<Module> modules = getActiveCategoryModules();

        // Lower rendering rows slightly if the text field is present
        int startY = (selectedCategory == Category.SEARCH) ? 80 : 55;
        int centerX = this.field_146294_l / 2;

        for (int i = 0; i < modules.size(); i++) {
            Module module = modules.get(i);
            int rowY = startY + (i * 24);
            if (rowY > this.field_146295_m - 60) break;

            // FIXED: Using the native public getName() getter method to bypass private field visibility rules
            String label = module.getName() + ": " + (module.isEnabled() ? "ON" : "OFF");
            this.field_146292_n.add(new GuiButton(200 + i, centerX - 100, rowY, 130, 20, label));

            String keyLabel = (awaitingBind == module) ? "..." : (module.getKeyCode() == -1 ? "Bind" : Keyboard.getKeyName(module.getKeyCode()));
            this.field_146292_n.add(new GuiButton(400 + i, centerX + 35, rowY, 65, 20, keyLabel));

            if (module instanceof HandView || module instanceof CrystalColor || module instanceof CrystalAura || module instanceof Proxy || module instanceof BedAura) {
                this.field_146292_n.add(new GuiButton(300 + i, centerX + 105, rowY, 35, 20, "Edit"));
            }
        }
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == 999) {
            this.field_146297_k.func_147108_a(parent);
            return;
        }

        if (button.field_146127_k >= 100 && button.field_146127_k < 100 + Category.values().length) {
            selectedCategory = Category.values()[button.field_146127_k - 100];
            awaitingBind = null;
            if (selectedCategory != Category.SEARCH) searchQuery = "";
            func_73866_w_();
            return;
        }

        if (button.field_146127_k >= 400) {
            List<Module> modules = getActiveCategoryModules();
            int index = button.field_146127_k - 400;
            if (index >= 0 && index < modules.size()) {
                awaitingBind = modules.get(index);
                func_73866_w_();
            }
            return;
        }

        if (button.field_146127_k >= 300 && button.field_146127_k < 400) {
            List<Module> modules = getActiveCategoryModules();
            int index = button.field_146127_k - 300;
            if (index >= 0 && index < modules.size()) {
                Module module = modules.get(index);
                if (module instanceof HandView) this.field_146297_k.func_147108_a(new HandViewConfigScreen(this, (HandView) module));
                else if (module instanceof CrystalColor) this.field_146297_k.func_147108_a(new CrystalColorConfigScreen(this, (CrystalColor) module));
                else if (module instanceof CrystalAura) this.field_146297_k.func_147108_a(new CrystalAuraConfigScreen(this));
                else if (module instanceof Proxy) this.field_146297_k.func_147108_a(new ProxyConfigScreen(this, (Proxy) module));
                else if (module instanceof BedAura) this.field_146297_k.func_147108_a(new BedAuraConfigScreen(this, (BedAura) module));
            }
            return;
        }

        if (button.field_146127_k >= 200 && button.field_146127_k < 300) {
            List<Module> modules = getActiveCategoryModules();
            int index = button.field_146127_k - 200;
            if (index >= 0 && index < modules.size()) {
                modules.get(index).setEnabled(!modules.get(index).isEnabled());
                func_73866_w_();
            }
        }
    }

    private List<Module> getActiveCategoryModules() {
        if (selectedCategory == Category.SEARCH) {
            List<Module> searchResults = new ArrayList<>();
            for (Category cat : Category.values()) {
                if (cat == Category.SEARCH) continue;
                List<Module> categoryModules = ModuleManager.getModulesByCategory(cat);
                if (categoryModules != null) {
                    for (Module m : categoryModules) {
                        // FIXED: Using public getName() to securely check string query data parameters
                        if (m != null && m.getName().toLowerCase().contains(searchQuery.toLowerCase())) {
                            searchResults.add(m);
                        }
                    }
                }
            }
            return searchResults;
        }
        return ModuleManager.getModulesByCategory(selectedCategory);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (awaitingBind != null) {
            if (keyCode == Keyboard.KEY_ESCAPE) {
                awaitingBind.setKeyCode(-1);
            } else {
                awaitingBind.setKeyCode(keyCode);
            }
            awaitingBind = null;
            func_73866_w_();
            return;
        }

        if (selectedCategory == Category.SEARCH && searchField.func_146206_l()) {
            searchField.func_146201_a(typedChar, keyCode);
            searchQuery = searchField.func_146179_b();

            this.field_146292_n.removeIf(b -> b.field_146127_k >= 200 && b.field_146127_k < 900);
            addModuleButtons();
            return;
        }

        super.func_73869_a(typedChar, keyCode);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);
        if (selectedCategory == Category.SEARCH && this.searchField != null) {
            this.searchField.func_146192_a(mouseX, mouseY, mouseButton);
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);

        int centerX = this.field_146294_l / 2;
        this.func_73732_a(this.field_146289_q, "SoleHack Config", centerX, 10, 0xFFFFFF);

        if (selectedCategory == Category.SEARCH && this.searchField != null) {
            this.searchField.func_146194_f();
            if (searchField.func_146179_b().isEmpty() && !searchField.func_146206_l()) {
                this.func_73731_b(this.field_146289_q, "Type module name...", centerX - 94, 58, 0x777777);
            }
        }

        if (awaitingBind != null) {
            // FIXED: Patched private access warning line to use public getName() tracker mapping securely
            this.func_73732_a(this.field_146289_q, "Press a key to bind \"" + awaitingBind.getName() + "\" (ESC to clear)", centerX, this.field_146295_m - 45, 0xFFFF55);
        }
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return "";
        return s.charAt(0) + s.substring(1).toLowerCase();
    }
}
