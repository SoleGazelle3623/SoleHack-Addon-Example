package com.yourwebsitespace.solehack.mixin.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketUseEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(NetHandlerPlayClient.class)
public class MixinNetHandlerPlayClient {


    @Inject(method = "sendPacket", at = @At("HEAD"))
    private void onSendPacket(Packet<?> packet, CallbackInfo ci) {
        if (packet instanceof CPacketUseEntity) {
            CPacketUseEntity useEntity = (CPacketUseEntity) packet;

            if (useEntity.func_149565_c() == CPacketUseEntity.Action.ATTACK) {
                Minecraft mc = Minecraft.func_71410_x();
                if (mc.field_71441_e != null) {
                    Entity entity = useEntity.func_149564_a(mc.field_71441_e);
                    if (entity instanceof EntityEnderCrystal) {
                        entity.func_70106_y(); // Fast despawn prediction
                    }
                }
            }
        }
    }
}