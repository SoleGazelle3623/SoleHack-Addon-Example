package com.yourwebsitespace.solehack.modules.render;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.tileentity.*;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class StorageESP extends Module {

    private static final Minecraft mc = Minecraft.func_71410_x();

    public StorageESP() {
        super("StorageESP", Category.RENDER);
    }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        // Save current OpenGL state and disable depth/lighting for ESP effect
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();

        GlStateManager.func_179090_x();
        GlStateManager.func_179140_f();
        GlStateManager.func_179097_i();
        GlStateManager.func_187441_d(1.5F);

        double renderPosX = mc.func_175598_ae().field_78730_l;
        double renderPosY = mc.func_175598_ae().field_78731_m;
        double renderPosZ = mc.func_175598_ae().field_78728_n;

        for (TileEntity tileEntity : mc.field_71441_e.field_147482_g) {
            BlockPos pos = tileEntity.func_174877_v();
            double x = pos.func_177958_n() - renderPosX;
            double y = pos.func_177956_o() - renderPosY;
            double z = pos.func_177952_p() - renderPosZ;

            AxisAlignedBB bb = new AxisAlignedBB(x, y, z, x + 1.0, y + 1.0, z + 1.0);

            // Color coding based on container type
            if (tileEntity instanceof TileEntityChest) {
                // Regular Chest: Orange / Gold
                drawStorageBox(bb, 1.0F, 0.6F, 0.0F, 0.4F, true);
            } else if (tileEntity instanceof TileEntityEnderChest) {
                // Ender Chest: Purple / Magenta
                drawStorageBox(bb, 0.8F, 0.2F, 1.0F, 0.4F, true);
            } else if (tileEntity instanceof TileEntityShulkerBox) {
                // Shulker Box: Cyan / Sky Blue
                drawStorageBox(bb, 0.0F, 0.8F, 1.0F, 0.4F, true);
            } else if (tileEntity instanceof TileEntityDispenser || tileEntity instanceof TileEntityDropper || tileEntity instanceof TileEntityHopper) {
                // Automation: Gray
                drawStorageBox(bb, 0.6F, 0.6F, 0.6F, 0.3F, false);
            } else if (tileEntity instanceof TileEntityFurnace) {
                // Furnace: Red / Orange
                drawStorageBox(bb, 1.0F, 0.2F, 0.0F, 0.3F, false);
            }
        }

        // Restore OpenGL state
        GlStateManager.func_179126_j();
        GlStateManager.func_179145_e();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    private void drawStorageBox(AxisAlignedBB bb, float red, float green, float blue, float alpha, boolean fill) {
        // Draw outline
        RenderGlobal.func_189694_a(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb.field_72337_e, bb.field_72334_f, red, green, blue, alpha * 2.0F);

        // Optional translucent box fill
        if (fill) {
            RenderGlobal.func_189695_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb.field_72337_e, bb.field_72334_f, red, green, blue, alpha * 0.5F);
        }
    }

    @Override
    protected void onUpdate() {

    }
}
