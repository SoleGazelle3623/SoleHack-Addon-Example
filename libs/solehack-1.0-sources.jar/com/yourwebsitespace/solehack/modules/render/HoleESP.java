package com.yourwebsitespace.solehack.modules.render;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class HoleESP extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // Configurable rendering properties
    public int scanRange = 8; // Sphere radius block field size to scan around the player

    private final List<HoleInfo> safeHoles = new ArrayList<>();

    public HoleESP() {
        super("HoleESP", Category.RENDER);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
        synchronized (safeHoles) {
            safeHoles.clear();
        }
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        synchronized (safeHoles) {
            safeHoles.clear();
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        List<HoleInfo> tempHoles = new ArrayList<>();

        int playerX = MathHelper.func_76128_c(mc.field_71439_g.field_70165_t);
        int playerY = MathHelper.func_76128_c(mc.field_71439_g.field_70163_u);
        int playerZ = MathHelper.func_76128_c(mc.field_71439_g.field_70161_v);

        // Raw 3D integer coordinate traversal iteration loop (Prevents BlockPos collection bugs)
        for (int x = playerX - scanRange; x <= playerX + scanRange; x++) {
            for (int y = playerY - 4; y <= playerY + 4; y++) { // Limit Y-axis to save performance frames
                for (int z = playerZ - scanRange; z <= playerZ + scanRange; z++) {
                    BlockPos pos = new BlockPos(x, y, z);

                    // A valid hole must be an open air block, with open air directly above it too
                    if (mc.field_71441_e.func_175623_d(pos) && mc.field_71441_e.func_175623_d(pos.func_177984_a()) && mc.field_71441_e.func_175623_d(pos.func_177981_b(2))) {
                        HoleType type = checkHoleType(pos);
                        if (type != HoleType.NONE) {
                            tempHoles.add(new HoleInfo(pos, type));
                        }
                    }
                }
            }
        }

        synchronized (safeHoles) {
            safeHoles.clear();
            safeHoles.addAll(tempHoles);
        }
    }

    private HoleType checkHoleType(BlockPos pos) {
        BlockPos[] sides = new BlockPos[] {
                pos.func_177977_b(), pos.func_177978_c(), pos.func_177968_d(), pos.func_177974_f(), pos.func_177976_e()
        };

        boolean isBedrock = true;
        boolean isObsidian = true;

        for (BlockPos side : sides) {
            net.minecraft.block.Block block = mc.field_71441_e.func_180495_p(side).func_177230_c();

            if (block != Blocks.field_150357_h) {
                isBedrock = false; // If even 1 wall is obsidian, it's not a pure Bedrock hole
            }
            if (block != Blocks.field_150343_Z && block != Blocks.field_150357_h) {
                isObsidian = false; // If any wall is dirt/stone/air, it's unsafe from crystals
            }
        }

        if (isBedrock) return HoleType.BEDROCK;
        if (isObsidian) return HoleType.OBSIDIAN;

        return HoleType.NONE;
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || !this.isEnabled()) {
            return;
        }

        List<HoleInfo> renderTargets;
        synchronized (safeHoles) {
            if (safeHoles.isEmpty()) return;
            renderTargets = new ArrayList<>(safeHoles);
        }

        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(2.0f);

        for (HoleInfo hole : renderTargets) {
            BlockPos pos = hole.pos;

            // Calculate absolute relative positioning offset against camera viewer metrics
            double renderX = pos.func_177958_n() - mc.func_175598_ae().field_78730_l;
            double renderY = pos.func_177956_o() - mc.func_175598_ae().field_78731_m;
            double renderZ = pos.func_177952_p() - mc.func_175598_ae().field_78728_n;

            // Box shape spans only 0.2 blocks high along the ground floor layer of the hole
            AxisAlignedBB bb = new AxisAlignedBB(renderX, renderY, renderZ, renderX + 1.0, renderY + 0.2, renderZ + 1.0);

            // Red/Green color assignment profile properties
            float r = (hole.type == HoleType.BEDROCK) ? 0.0f : 1.0f; // Green if Bedrock, Red if Obsidian
            float g = (hole.type == HoleType.BEDROCK) ? 1.0f : 0.0f;
            float b = 0.0f;

            // Render clear translucent box floor and outer skeleton frame wire meshes
            RenderGlobal.func_189696_b(bb, r, g, b, 0.15f);
            RenderGlobal.func_189697_a(bb, r, g, b, 0.7f);
        }

        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179126_j();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    @Override
    protected void onUpdate() {}

    // Inner framework data mapping enums and objects
    private enum HoleType { NONE, OBSIDIAN, BEDROCK }

    private static class HoleInfo {
        public final BlockPos pos;
        public final HoleType type;

        public HoleInfo(BlockPos pos, HoleType type) {
            this.pos = pos;
            this.type = type;
        }
    }
}
