package com.yourwebsitespace.solehack.modules.render;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Nametag extends Module {

    public Nametag() {
        super("Nametag", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    protected void onUpdate() {

    }

    @Override
    protected void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onRenderLiving(RenderLivingEvent.Specials.Pre event) {
        if (!(event.getEntity() instanceof EntityPlayer)) return;
        if (event.getEntity() instanceof EntityPlayerSP) return; // skip yourself

        EntityPlayer target = (EntityPlayer) event.getEntity();
        Minecraft mc = Minecraft.func_71410_x();

        float health = target.func_110143_aJ();
        float maxHealth = target.func_110138_aP();
        int armor = target.func_70658_aO(); // 0-20 scale, vanilla armor points
        ItemStack offhand = target.func_184592_cb();
        String offhandName = offhand.func_190926_b() ? "Empty" : offhand.func_82833_r();

        String line = String.format("HP: %.1f/%.1f  Armor: %d  Offhand: %s",
                health, maxHealth, armor, offhandName);

        double x = event.getX();
        double y = event.getY() + target.field_70131_O + 0.5; // just above the vanilla nametag
        double z = event.getZ();

        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b(x, y, z);
        GlStateManager.func_179114_b(-mc.func_175598_ae().field_78735_i, 0f, 1f, 0f);
        GlStateManager.func_179114_b(mc.func_175598_ae().field_78732_j, 1f, 0f, 0f);
        GlStateManager.func_179152_a(-0.025f, -0.025f, 0.025f);
        GlStateManager.func_179140_f();
        GlStateManager.func_179132_a(false);
        GlStateManager.func_179147_l();

        int width = mc.field_71466_p.func_78256_a(line);
        mc.field_71466_p.func_78276_b(line, -width / 2, 0, 0xFFFFFF);

        GlStateManager.func_179132_a(true);
        GlStateManager.func_179145_e();
        GlStateManager.func_179121_F();
    }
}