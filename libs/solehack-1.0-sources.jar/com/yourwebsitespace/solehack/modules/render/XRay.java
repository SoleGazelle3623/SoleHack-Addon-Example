package com.yourwebsitespace.solehack.modules.render;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class XRay extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // Configuration parameters
    public int scanRange = 12; // Radius block reach to scan underground

    private final List<BlockPos> targetBlocks = new ArrayList<>();

    public XRay() {
        super("XRay", Category.RENDER);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
        synchronized (targetBlocks) {
            targetBlocks.clear();
        }
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        synchronized (targetBlocks) {
            targetBlocks.clear();
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        List<BlockPos> discoveredBlocks = new ArrayList<>();

        int playerX = MathHelper.func_76128_c(mc.field_71439_g.field_70165_t);
        int playerY = MathHelper.func_76128_c(mc.field_71439_g.field_70163_u);
        int playerZ = MathHelper.func_76128_c(mc.field_71439_g.field_70161_v);

        // Scan the 3D grid chunk field surrounding the player using safe primitives
        for (int x = playerX - scanRange; x <= playerX + scanRange; x++) {
            for (int y = Math.max(0, playerY - 6); y <= Math.min(255, playerY + 6); y++) { // Throttled Y-height to optimize client FPS
                for (int z = playerZ - scanRange; z <= playerZ + scanRange; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    Block block = mc.field_71441_e.func_180495_p(pos).func_177230_c();

                    // Filter criteria list: Tracks rare ores and utility blocks hidden inside the terrain
                    if (block == Blocks.field_150482_ag || block == Blocks.field_150412_bA || block == Blocks.field_150486_ae || block == Blocks.field_150477_bB) {
                        discoveredBlocks.add(pos);
                    }
                }
            }
        }

        // Thread-safe generic allocation swap into cache loop array
        synchronized (targetBlocks) {
            targetBlocks.clear();
            targetBlocks.addAll(discoveredBlocks);
        }
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || !this.isEnabled()) {
            return;
        }

        List<BlockPos> renderList;
        synchronized (targetBlocks) {
            if (targetBlocks.isEmpty()) return;
            renderList = new ArrayList<>(targetBlocks);
        }

        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i(); // CRUCIAL: Disabling the depth buffer test forces graphics to display through solid blocks
        GlStateManager.func_179120_a(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(2.5f);

        for (BlockPos pos : renderList) {
            // Translate absolute world variables into camera matrix relative rendering offsets
            double renderX = pos.func_177958_n() - mc.func_175598_ae().field_78730_l;
            double renderY = pos.func_177956_o() - mc.func_175598_ae().field_78731_m;
            double renderZ = pos.func_177952_p() - mc.func_175598_ae().field_78728_n;

            AxisAlignedBB bb = new AxisAlignedBB(renderX, renderY, renderZ, renderX + 1.0, renderY + 1.0, renderZ + 1.0);

            // Fetch block definitions to paint targeted elements accurately
            Block type = mc.field_71441_e.func_180495_p(pos).func_177230_c();
            float r = 1.0f, g = 1.0f, b = 1.0f; // Default White marker

            if (type == Blocks.field_150482_ag) { r = 0.0f; g = 0.8f; b = 1.0f; }      // Diamond Blue
            else if (type == Blocks.field_150412_bA) { r = 0.0f; g = 1.0f; b = 0.0f; } // Emerald Green
            else if (type == Blocks.field_150486_ae || type == Blocks.field_150477_bB) { r = 1.0f; g = 0.5f; b = 0.0f; } // Chest Orange

            // Render crisp transparent fill and outer frame wireframes visible everywhere
            RenderGlobal.func_189696_b(bb, r, g, b, 0.12f);
            RenderGlobal.func_189697_a(bb, r, g, b, 0.75f);
        }

        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179126_j(); // Return deep coordinate pipeline metrics back to vanilla defaults
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    @Override
    protected void onUpdate() {}
}
