package com.yourwebsitespace.solehack.modules.render;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

public class FullBright extends Module {

    private float savedGamma;

    public FullBright() {
        super("FullBright", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        GameSettings settings = Minecraft.func_71410_x().field_71474_y;
        savedGamma = settings.field_74333_Y;
        settings.field_74333_Y = 1000.0F; // vanilla caps the slider at 1.0, but the field itself accepts much higher
    }

    @Override
    protected void onUpdate() {

    }

    @Override
    protected void onDisable() {
        Minecraft.func_71410_x().field_71474_y.field_74333_Y = savedGamma;
    }
}