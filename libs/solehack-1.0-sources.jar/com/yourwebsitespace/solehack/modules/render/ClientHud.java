package com.yourwebsitespace.solehack.modules.render;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import com.yourwebsitespace.solehack.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ClientHud extends Module {

    private static int kills = 0;
    private static int deaths = 0;

    private static final float SCALE = 1.2f;

    public ClientHud() {
        super("ClientHud", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    protected void onUpdate() {

    }

    @Override
    protected void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71439_g == null) return;

        if (event.getEntityLiving() == mc.field_71439_g) {
            deaths++;
        } else if (event.getEntityLiving().func_94060_bK() == mc.field_71439_g) {
            kills++;
        }
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) return;

        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71439_g == null) return;

        FontRenderer fr = mc.field_71466_p;

        GlStateManager.func_179094_E();
        GlStateManager.func_179152_a(SCALE, SCALE, 1f);

        // Scaled coordinate space: real screen pos / SCALE
        int x = (int) (5 / SCALE);
        int y = (int) (5 / SCALE);

        fr.func_175063_a("SoleHack 1.0", x, y, 0x55FFFF);
        y += (fr.field_78288_b + 3);
        fr.func_175063_a("FPS: " + Minecraft.func_175610_ah(), x, y, 0xFFFFFF);
        y += (fr.field_78288_b + 3);
        fr.func_175063_a("Ping: " + getPing() + "ms", x, y, 0xFFFFFF);
        y += (fr.field_78288_b + 3);
        fr.func_175063_a("K/D: " + kills + "/" + deaths, x, y, 0xFFFFFF);

        // Coordinates, pinned to the bottom-right corner of the screen.
        ScaledResolution sr = new ScaledResolution(mc);
        int screenWidth = (int) (sr.func_78326_a() / SCALE);
        int screenHeight = (int) (sr.func_78328_b() / SCALE);
        int margin = (int) (5 / SCALE);

        String coords = String.format("XYZ: %.1f, %.1f, %.1f",
                mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
        int coordsX = screenWidth - fr.func_78256_a(coords) - margin;
        int coordsY = screenHeight - fr.field_78288_b - margin;
        fr.func_175063_a(coords, coordsX, coordsY, 0xFFFFFF);

        // Enabled module list ("ArrayList"), right-aligned in the top-right
        // corner, stacked downward - the layout most clients use.
        List<Module> enabled = ModuleManager.getAll().stream()
                .filter(Module::isEnabled)
                .sorted(Comparator.comparing(m -> -fr.func_78256_a(m.getName())))
                .collect(Collectors.toList());

        int listY = (int) (5 / SCALE);
        for (Module module : enabled) {
            String name = module.getName();
            int listX = screenWidth - fr.func_78256_a(name) - margin;
            fr.func_175063_a(name, listX, listY, 0xFFFFFF);
            listY += (fr.field_78288_b + 3);
        }

        GlStateManager.func_179121_F();
    }

    private int getPing() {
        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71439_g == null || mc.func_147114_u() == null) return 0;

        NetworkPlayerInfo info = mc.func_147114_u().func_175102_a(mc.field_71439_g.func_146103_bH().getId());
        return info != null ? info.func_178853_c() : 0;
    }
}