package com.yourwebsitespace.solehack.modules.render;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class Tracers extends Module {

    private static final Minecraft mc = Minecraft.func_71410_x();

    public Tracers() {
        super("Tracers", Category.RENDER);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
        super.onEnable();
    }

    @Override
    protected void onUpdate() {

    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        super.onDisable();
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        float partialTicks = event.getPartialTicks();

        // Retrieve internal camera positions from RenderManager
        double renderPosX = mc.func_175598_ae().field_78730_l;
        double renderPosY = mc.func_175598_ae().field_78731_m;
        double renderPosZ = mc.func_175598_ae().field_78728_n;

        // Establish look vector for center-screen tracing alignment
        Vec3d cameraLook = new Vec3d(0, 0, 1)
                .func_178789_a(-(float)Math.toRadians(mc.field_71439_g.field_70125_A))
                .func_178785_b(-(float)Math.toRadians(mc.field_71439_g.field_70177_z));

        // OpenGL Setup
        GlStateManager.func_179094_E();
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179132_a(false);
        GlStateManager.func_179120_a(770, 771, 1, 0);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GlStateManager.func_187441_d(1.5f);

        for (EntityPlayer targetPlayer : mc.field_71441_e.field_73010_i) {
            // Filter target criteria
            if (targetPlayer == mc.field_71439_g || targetPlayer.field_70128_L || targetPlayer.func_82150_aj()) {
                continue;
            }

            // Interpolate target positions over current partial ticks
            double targetX = targetPlayer.field_70142_S + (targetPlayer.field_70165_t - targetPlayer.field_70142_S) * partialTicks - renderPosX;
            double targetY = targetPlayer.field_70137_T + (targetPlayer.field_70163_u - targetPlayer.field_70137_T) * partialTicks - renderPosY;
            double targetZ = targetPlayer.field_70136_U + (targetPlayer.field_70161_v - targetPlayer.field_70136_U) * partialTicks - renderPosZ;

            // Render Tracer Line
            GlStateManager.func_179131_c(0.0f, 1.0f, 0.0f, 0.6f); // Green tracer lines

            GL11.glBegin(GL11.GL_LINES);
            // Screen vector origin point
            GL11.glVertex3d(cameraLook.field_72450_a, cameraLook.field_72448_b + mc.field_71439_g.func_70047_e(), cameraLook.field_72449_c);
            // Player feet location destination point
            GL11.glVertex3d(targetX, targetY, targetZ);
            GL11.glEnd();
        }

        // Cleanup state machines
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179084_k();
        GlStateManager.func_179098_w();
        GlStateManager.func_179121_F();
    }
}
