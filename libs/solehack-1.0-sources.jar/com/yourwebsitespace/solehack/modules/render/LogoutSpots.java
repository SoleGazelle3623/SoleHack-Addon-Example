package com.yourwebsitespace.solehack.modules.render;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LogoutSpots extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();
    public static LogoutSpots INSTANCE;

    public final List<LogoutSpot> spots = new ArrayList<>();
    private final Set<String> previousPlayers = new HashSet<>();

    public LogoutSpots() {
        super("LogoutSpots", Category.RENDER);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
        spots.clear();
        previousPlayers.clear();
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        spots.clear();
        previousPlayers.clear();
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) return;
        if (!this.isEnabled()) return;

        Set<String> currentPlayers = new HashSet<>();
        for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
            if (player == mc.field_71439_g) continue;
            currentPlayers.add(player.func_70005_c_());

            // Remove from logout spots if they reconnect or come back into range
            spots.removeIf(spot -> spot.name.equalsIgnoreCase(player.func_70005_c_()));
        }

        // Cleaned up empty statement check
        for (String playerName : previousPlayers) {
            if (!currentPlayers.contains(playerName)) {
                // Handle player disappearance if desired
            }
        }

        previousPlayers.clear();
        previousPlayers.addAll(currentPlayers);
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || spots.isEmpty()) return;

        for (LogoutSpot spot : spots) {
            renderLogoutBox(spot);
            renderNameTag(spot);
        }
    }

    private void renderLogoutBox(LogoutSpot spot) {
        AxisAlignedBB bb = new AxisAlignedBB(
                spot.position.field_72450_a - 0.3, spot.position.field_72448_b, spot.position.field_72449_c - 0.3,
                spot.position.field_72450_a + 0.3, spot.position.field_72448_b + 1.8, spot.position.field_72449_c + 0.3
        );

        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179120_a(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);

        double renderPosX = mc.func_175598_ae().field_78730_l;
        double renderPosY = mc.func_175598_ae().field_78731_m;
        double renderPosZ = mc.func_175598_ae().field_78728_n;

        AxisAlignedBB translatedBB = bb.func_72317_d(-renderPosX, -renderPosY, -renderPosZ);

        // Standard 1.12.2 BufferBuilder box renderer
        drawBoundingBox(translatedBB, 1.0f, 0.3f, 0.3f, 0.3f);

        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    private void drawBoundingBox(AxisAlignedBB bb, float red, float green, float blue, float alpha) {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder buffer = tessellator.func_178180_c();

        buffer.func_181668_a(GL11.GL_LINE_STRIP, DefaultVertexFormats.field_181706_f);

        // Draw outline edges
        buffer.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();

        buffer.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();

        buffer.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();

        buffer.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();

        buffer.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
        buffer.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();

        tessellator.func_78381_a();
    }

    private void renderNameTag(LogoutSpot spot) {
        double x = spot.position.field_72450_a - mc.func_175598_ae().field_78730_l;
        double y = spot.position.field_72448_b + 2.0 - mc.func_175598_ae().field_78731_m;
        double z = spot.position.field_72449_c - mc.func_175598_ae().field_78728_n;

        GlStateManager.func_179094_E();
        GlStateManager.func_179137_b(x, y, z);
        GlStateManager.func_187432_a(0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(-mc.func_175598_ae().field_78735_i, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(mc.func_175598_ae().field_78732_j, 1.0F, 0.0F, 0.0F);

        float scale = 0.025f;
        GlStateManager.func_179152_a(-scale, -scale, scale);

        GlStateManager.func_179140_f();
        GlStateManager.func_179132_a(false);

        String text = spot.name + " (Logout)";
        int width = mc.field_71466_p.func_78256_a(text) / 2;

        mc.field_71466_p.func_175063_a(text, -width, 0, 0xFFFF5555);

        GlStateManager.func_179132_a(true);
        GlStateManager.func_179145_e();
        GlStateManager.func_179121_F();
    }

    public static class LogoutSpot {
        public final String name;
        public final Vec3d position;
        public final long timestamp;

        public LogoutSpot(String name, Vec3d position) {
            this.name = name;
            this.position = position;
            this.timestamp = System.currentTimeMillis();
        }
    }

    @Override
    protected void onUpdate() {}
}