package com.yourwebsitespace.solehack.modules.render;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.client.config.GuiSlider;

public class HandViewConfigScreen extends GuiScreen {

    private final GuiScreen parent;
    private final HandView handView;

    private static final int ID_SCALE = 1;
    private static final int ID_OFFSET_X = 2;
    private static final int ID_OFFSET_Y = 3;
    private static final int ID_OFFSET_Z = 4;
    private static final int ID_DONE = 999;

    public HandViewConfigScreen(GuiScreen parent, HandView handView) {
        this.parent = parent;
        this.handView = handView;
    }

    @Override
    public void func_73866_w_() {
        this.field_146292_n.clear();

        int centerX = this.field_146294_l / 2;
        int width = 200;
        int startY = 50;
        int spacing = 26;

        this.field_146292_n.add(new GuiSlider(ID_SCALE, centerX - width / 2, startY, width, 20,
                "Scale: ", "", 0.1, 2.0, handView.getScale(), false, true));

        this.field_146292_n.add(new GuiSlider(ID_OFFSET_X, centerX - width / 2, startY + spacing, width, 20,
                "Offset X: ", "", -1.0, 1.0, handView.getOffsetX(), false, true));

        this.field_146292_n.add(new GuiSlider(ID_OFFSET_Y, centerX - width / 2, startY + spacing * 2, width, 20,
                "Offset Y: ", "", -1.0, 1.0, handView.getOffsetY(), false, true));

        this.field_146292_n.add(new GuiSlider(ID_OFFSET_Z, centerX - width / 2, startY + spacing * 3, width, 20,
                "Offset Z: ", "", -1.0, 1.0, handView.getOffsetZ(), false, true));

        this.field_146292_n.add(new GuiButton(ID_DONE, centerX - 100, this.field_146295_m - 30, 200, 20, "Done"));
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == ID_DONE) {
            this.field_146297_k.func_147108_a(parent);
            return;
        }

        if (button instanceof GuiSlider) {
            GuiSlider slider = (GuiSlider) button;
            float value = (float) slider.getValue();

            switch (button.field_146127_k) {
                case ID_SCALE:
                    handView.setScale(value);
                    break;
                case ID_OFFSET_X:
                    handView.setOffsetX(value);
                    break;
                case ID_OFFSET_Y:
                    handView.setOffsetY(value);
                    break;
                case ID_OFFSET_Z:
                    handView.setOffsetZ(value);
                    break;
            }
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_73732_a(this.field_146289_q, "HandView Config", this.field_146294_l / 2, 15, 0xFFFFFF);
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }
}