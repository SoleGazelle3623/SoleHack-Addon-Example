package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ElytraFly extends Module {
    private final Minecraft mc = Minecraft.func_71410_x();

    // Configurations
    private final double horizontalSpeed = 2.6; // Custom horizontal speed multiplier
    private boolean isDoubleJumping = false;
    private boolean wasJumpPressed = false;
    private int jumpTicks = 0;

    public ElytraFly() {
        super("ElytraFly", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
        resetFlightState();
    }

    @Override
    protected void onUpdate() {

    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        resetFlightState();
    }

    private void resetFlightState() {
        isDoubleJumping = false;
        wasJumpPressed = false;
        jumpTicks = 0;
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (!this.isEnabled() || mc.field_71439_g == null) return;
        EntityPlayer player = mc.field_71439_g;

        // Only run code on the client side local player
        if (player.field_70170_p.field_72995_K && player.equals(mc.field_71439_g)) {

            // 1. Reset state when touching the ground
            if (player.field_70122_E) {
                isDoubleJumping = false;
            }

            // 2. Double-jump detection logic
            boolean isJumpPressed = mc.field_71474_y.field_74314_A.func_151470_d();

            if (jumpTicks > 0) {
                jumpTicks--;
            }

            if (isJumpPressed && !wasJumpPressed) { // Key pressed event
                if (!player.field_70122_E && !isDoubleJumping) {
                    if (jumpTicks > 0) {
                        isDoubleJumping = true; // Trigger double jump flight
                    } else {
                        jumpTicks = 7; // Window of ticks to press jump again
                    }
                }
            }
            wasJumpPressed = isJumpPressed;

            // 3. Movement execution during double jump flight
            if (isDoubleJumping) {
                // Force Elytra fall-flying state packet flag
                if (!player.func_184613_cA()) {
                    player.func_70050_g(7);
                }

                // Vertical control
                if (mc.field_71474_y.field_74314_A.func_151470_d()) {
                    player.field_70181_x += 0.08;
                } else if (mc.field_71474_y.field_74311_E.func_151470_d()) {
                    player.field_70181_x -= 0.08;
                } else {
                    player.field_70181_x = 0.0; // Altitude lock hover
                }

                // Horizontal speed enhancement based on player's current look direction
                float moveForward = ((net.minecraft.client.entity.EntityPlayerSP) player).field_71158_b.field_192832_b;
                float moveStrafe = ((net.minecraft.client.entity.EntityPlayerSP) player).field_71158_b.field_78902_a;

                if (moveForward != 0.0F || moveStrafe != 0.0F) {
                    // Combine angles to match directional movement input
                    float yaw = player.field_70177_z;
                    if (moveForward < 0.0F) yaw += 180.0F;
                    if (moveStrafe > 0.0F) yaw -= 90.0F * (moveForward < 0.0F ? -0.5F : (moveForward > 0.0F ? 0.5F : 1.0F));
                    if (moveStrafe < 0.0F) yaw += 90.0F * (moveForward < 0.0F ? -0.5F : (moveForward > 0.0F ? 0.5F : 1.0F));

                    double radians = Math.toRadians(yaw);
                    player.field_70159_w = -MathHelper.func_76126_a((float) radians) * horizontalSpeed;
                    player.field_70179_y = MathHelper.func_76134_b((float) radians) * horizontalSpeed;
                } else {
                    // Instantly halt horizontal drifting when inputs are released
                    player.field_70159_w = 0.0;
                    player.field_70179_y = 0.0;
                }
            }
        }
    }
}
