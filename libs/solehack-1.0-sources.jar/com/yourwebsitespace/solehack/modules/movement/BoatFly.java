package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.util.EnumHand;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class BoatFly extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // Settings
    public double speed = 2.5;
    public double verticalSpeed = 0.5;
    public boolean glide = true;
    public boolean cancelGravity = true;

    public BoatFly() {
        super("BoatFly", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    protected void onUpdate() {

    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        // Check if player is sitting in a boat
        if (mc.field_71439_g.func_184187_bx() instanceof EntityBoat) {
            EntityBoat boat = (EntityBoat) mc.field_71439_g.func_184187_bx();

            double motionX = 0.0;
            double motionY = 0.0;
            double motionZ = 0.0;

            // Handle Vertical Movement
            if (mc.field_71474_y.field_74314_A.func_151470_d()) {
                motionY = verticalSpeed;
            } else if (mc.field_71474_y.field_151444_V.func_151470_d()) {
                motionY = -verticalSpeed;
            } else if (glide) {
                motionY = -0.04; // Slow hover drop
            } else if (!cancelGravity) {
                motionY = boat.field_70181_x;
            }

            // Handle Directional Movement (Forward, Strafe, Yaw)
            float forward = mc.field_71439_g.field_71158_b.field_192832_b;
            float strafe = mc.field_71439_g.field_71158_b.field_78902_a;
            float yaw = mc.field_71439_g.field_70177_z;

            // Sync boat orientation with player rotation so boat turns smoothly
            boat.field_70177_z = mc.field_71439_g.field_70177_z;

            if (forward != 0.0f || strafe != 0.0f) {
                if (forward != 0.0f) {
                    if (strafe > 0.0f) {
                        yaw += (forward > 0.0f ? -45 : 45);
                    } else if (strafe < 0.0f) {
                        yaw += (forward > 0.0f ? 45 : -45);
                    }
                    strafe = 0.0f;
                    if (forward > 0.0f) {
                        forward = 1.0f;
                    } else if (forward < 0.0f) {
                        forward = -1.0f;
                    }
                }

                double rad = Math.toRadians(yaw + 90.0f);
                motionX = (forward * speed * Math.cos(rad)) + (strafe * speed * Math.sin(rad));
                motionZ = (forward * speed * Math.sin(rad)) - (strafe * speed * Math.cos(rad));
            }

            // Apply direct motion vectors to the vehicle entity
            boat.field_70159_w = motionX;
            boat.field_70181_x = motionY;
            boat.field_70179_y = motionZ;

            // Optional arm swing visual when navigating
            if (forward != 0.0f || strafe != 0.0f || mc.field_71474_y.field_74314_A.func_151470_d()) {
                mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            }
        }
    }
}