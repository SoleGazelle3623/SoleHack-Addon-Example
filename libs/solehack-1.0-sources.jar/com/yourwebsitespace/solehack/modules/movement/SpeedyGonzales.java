package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class SpeedyGonzales extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // 0.2873 maps to the absolute highest vanilla sprint speed coefficient allowed by 1.12.2 server engines
    private final double vanillaSprintFactor = 0.2873;

    // Configured target: 2x the standard base movement speed threshold
    public double speedMultiplier = 2.0;

    public SpeedyGonzales() {
        // FIXED: Renamed the system module registration string identifier to SpeedyGonzales
        super("SpeedyGonzales", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        if (mc.field_71439_g != null) {
            mc.field_71439_g.func_70031_b(false);
        }
    }

    /**
     * 1. DIAGONAL INPUT EQUALIZATION
     * Removes the hardcoded vanilla penalty that slows you down when moving diagonally/sideways.
     */
    @SubscribeEvent
    public void onInputUpdate(InputUpdateEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || !this.isEnabled()) {
            return;
        }

        if (event.getMovementInput().field_192832_b != 0.0f || event.getMovementInput().field_78902_a != 0.0f) {
            if (!mc.field_71439_g.func_70051_ag() && !mc.field_71439_g.func_184587_cr()) {
                mc.field_71439_g.func_70031_b(true);
            }
        }
    }

    /**
     * 2. VELOCITY AMPLIFIER CONTROLLER
     * Applies the strict speed calculation scalar values continuously on the client thread.
     */
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        // FAIL-SAFE BYPASS: Instantly pause modifications inside liquid, climbing, or flying to prevent kicks
        if (mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab() || mc.field_71439_g.func_70617_f_() || mc.field_71439_g.field_71075_bZ.field_75100_b) {
            return;
        }

        // Collision Check Dampener: Reset acceleration instantly if scraping against walls
        if (mc.field_71439_g.field_70123_F) {
            return;
        }

        // Stop applying movement forces entirely if no input keys are physically being held down
        if (mc.field_71439_g.field_71158_b.field_192832_b == 0.0f && mc.field_71439_g.field_71158_b.field_78902_a == 0.0f) {
            mc.field_71439_g.field_70159_w = 0.0;
            mc.field_71439_g.field_70179_y = 0.0;
            return;
        }

        // Calculate dynamic maximum speed thresholds natively
        double calculatedSpeed = vanillaSprintFactor * speedMultiplier;

        // Apply Speed Potion amplification scaling smoothly if active
        PotionEffect speedEffect = mc.field_71439_g.func_70660_b(MobEffects.field_76424_c);
        if (mc.field_71439_g.func_70644_a(MobEffects.field_76424_c) && speedEffect != null) {
            int amplifier = speedEffect.func_76458_c();
            calculatedSpeed *= 1.0 + (0.2 * (amplifier + 1));
        }

        // Only scale up motion vectors when firmly contacting a block to pass strict air-momentum tracking rules
        if (mc.field_71439_g.field_70122_E) {
            applyMotionVelocity(calculatedSpeed);
        }
    }

    private void applyMotionVelocity(double speed) {
        float forward = mc.field_71439_g.field_71158_b.field_192832_b;
        float strafe = mc.field_71439_g.field_71158_b.field_78902_a;
        float yaw = mc.field_71439_g.field_70177_z;

        if (forward == 0.0f && strafe == 0.0f) {
            mc.field_71439_g.field_70159_w = 0.0;
            mc.field_71439_g.field_70179_y = 0.0;
        } else {
            if (forward != 0.0f) {
                if (strafe > 0.0f) {
                    yaw += (float) (forward > 0.0f ? -45 : 45);
                } else if (strafe < 0.0f) {
                    yaw += (float) (forward > 0.0f ? 45 : -45);
                }
                strafe = 0.0f;
                if (forward > 0.0f) {
                    forward = 1.0f;
                } else if (forward < 0.0f) {
                    forward = -1.0f;
                }
            }

            // Convert looking angle variations directly into exact Cartesian grid coordinate offsets
            double cos = Math.cos(Math.toRadians(yaw + 90.0f));
            double sin = Math.sin(Math.toRadians(yaw + 90.0f));

            // Inject the 2x scaled speed vectors directly into the local player's motion calculations
            mc.field_71439_g.field_70159_w = (double) forward * speed * cos + (double) strafe * speed * sin;
            mc.field_71439_g.field_70179_y = (double) forward * speed * sin - (double) strafe * speed * cos;
        }
    }

    @Override
    protected void onUpdate() {}
}
