package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class NoFall extends Module {

    public static NoFall INSTANCE;
    private final Minecraft mc = Minecraft.func_71410_x();

    public Mode mode = Mode.PACKET;

    public enum Mode {
        PACKET,  // Standard packet ground-spoofing
        CATCH    // Triggers right before hitting the ground (more subtle)
    }

    public NoFall() {
        super("NoFall", Category.MOVEMENT);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled() || mc.field_71439_g.func_184812_l_() || mc.field_71439_g.func_175149_v()) {
            return;
        }

        // Only process when falling significantly
        if (mc.field_71439_g.field_70143_R > 2.0f) {
            if (mode == Mode.PACKET) {
                // Force onGround state packet to mitigate server-side fall distance calculation
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer(true));
            } else if (mode == Mode.CATCH) {
                // Send ground spoof packet only when close to collision
                if (mc.field_71441_e.func_184143_b(mc.field_71439_g.func_174813_aQ().func_72317_d(0, -0.5, 0))) {
                    mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer(true));
                    mc.field_71439_g.field_70143_R = 0;
                }
            }
        }
    }

    @Override
    protected void onUpdate() {}
}