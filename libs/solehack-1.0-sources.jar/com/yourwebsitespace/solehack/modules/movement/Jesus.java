package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.block.BlockLiquid;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Jesus extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();
    public static Jesus INSTANCE;

    public Jesus() {
        super("Jesus", Category.MOVEMENT);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) return;
        if (!this.isEnabled()) return;

        // Check if player is touching liquid and trying to move up
        if (isInLiquid() && !mc.field_71439_g.func_70093_af() && !mc.field_71439_g.field_71158_b.field_78901_c) {
            mc.field_71439_g.field_70181_x = 0.11; // Slight upward push to stay on top of the fluid surface
            mc.field_71439_g.field_70122_E = true;
        }
    }

    private boolean isInLiquid() {
        if (mc.field_71439_g == null) return false;
        double y = mc.field_71439_g.field_70163_u - 0.05;
        for (int x = MathHelper.func_76128_c(mc.field_71439_g.field_70165_t); x <= MathHelper.func_76143_f(mc.field_71439_g.field_70165_t); x++) {
            for (int z = MathHelper.func_76128_c(mc.field_71439_g.field_70161_v); z <= MathHelper.func_76143_f(mc.field_71439_g.field_70161_v); z++) {
                BlockPos pos = new BlockPos(x, (int) y, z);
                if (mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof BlockLiquid) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    protected void onUpdate() {}
}