package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class PacketFly extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // 5b5t Strict Anti-Cheat Compliant Velocity Scales
    // Keeping speed below 0.05-0.07 bounds provides stable, slow packet flight bypasses
    public double horizontalSpeed = 0.045;
    public double verticalSpeed = 0.035;

    public PacketFly() {
        super("PacketFly", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        // Freeze all vanilla gravity updates instantly to prevent falling flags
        mc.field_71439_g.field_70159_w = 0.0;
        mc.field_71439_g.field_70181_x = 0.0;
        mc.field_71439_g.field_70179_y = 0.0;

        double radYaw = Math.toRadians(mc.field_71439_g.field_70177_z);
        double outX = 0.0;
        double outY = 0.0;
        double outZ = 0.0;

        // 1. Process directional movement inputs with tight horizontal constraints
        if (mc.field_71474_y.field_74351_w.func_151470_d()) {
            outX -= Math.sin(radYaw) * horizontalSpeed;
            outZ += Math.cos(radYaw) * horizontalSpeed;
        }
        if (mc.field_71474_y.field_74368_y.func_151470_d()) {
            outX += Math.sin(radYaw) * horizontalSpeed;
            outZ -= Math.cos(radYaw) * horizontalSpeed;
        }
        if (mc.field_71474_y.field_74370_x.func_151470_d()) {
            outX -= Math.cos(radYaw) * horizontalSpeed;
            outZ -= Math.sin(radYaw) * horizontalSpeed;
        }
        if (mc.field_71474_y.field_74366_z.func_151470_d()) {
            outX += Math.cos(radYaw) * horizontalSpeed;
            outZ += Math.sin(radYaw) * horizontalSpeed;
        }

        // 2. Process vertical ascension / descension inputs (Space / Shift)
        if (mc.field_71474_y.field_74314_A.func_151470_d()) {
            outY += verticalSpeed;
        }
        if (mc.field_71474_y.field_74311_E.func_151470_d()) {
            outY -= verticalSpeed;
        }

        // 3. PACKET-SPOOFING FLUID BYPASS LAYER
        // To counter strict server-side transaction checks, we send alternating micro-offsets
        // down the pipeline before updating our position to fool the position tracking engine.
        double posX = mc.field_71439_g.field_70165_t + outX;
        double posY = mc.field_71439_g.field_70163_u + outY;
        double posZ = mc.field_71439_g.field_70161_v + outZ;

        // Spoof a minor server-side offset confirmation packet sequence directly down the network wire
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(posX, posY - 0.04, posZ, false));
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(posX, posY, posZ, true));

        // Physically update the local client player entity location boundaries to match
        mc.field_71439_g.func_70107_b(posX, posY, posZ);
    }

    @Override
    protected void onUpdate() {}
}
