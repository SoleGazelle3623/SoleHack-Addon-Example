package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AutoScaffold extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // Anti-Cheat Profiling
    public boolean strictRotations = true;
    public boolean safeWalk = true;       // Prevents slipping off edges while packets process
    public boolean tower = true;          // Fast vertical pillar support

    public AutoScaffold() {
        super("AutoScaffold", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        int blockSlot = findBlockInHotbar();
        if (blockSlot == -1) {
            return; // Out of construction materials
        }

        // 1. SAFEWALK PREDICTION LOGIC: Calculate your next anticipated block boundary step
        double futureX = mc.field_71439_g.field_70165_t + (mc.field_71439_g.field_70159_w * 1.5);
        double futureZ = mc.field_71439_g.field_70161_v + (mc.field_71439_g.field_70179_y * 1.5);

        BlockPos playerFeetPos = new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u - 1.0), Math.floor(mc.field_71439_g.field_70161_v));
        BlockPos predictivePos = new BlockPos(Math.floor(futureX), Math.floor(mc.field_71439_g.field_70163_u - 1.0), Math.floor(futureZ));

        // Target the predictive gap block if moving quickly, otherwise default to current feet
        BlockPos targetPos = mc.field_71441_e.func_175623_d(predictivePos) ? predictivePos : playerFeetPos;

        if (!mc.field_71441_e.func_175623_d(targetPos)) {
            return;
        }

        // 2. EQUALIZATION DAMPER: Slow down slightly over open gaps to prevent anti-cheat speed violations
        if (safeWalk && mc.field_71439_g.field_70122_E && mc.field_71441_e.func_175623_d(targetPos)) {
            mc.field_71439_g.field_70159_w *= 0.65;
            mc.field_71439_g.field_70179_y *= 0.65;
        }

        // Scan neighboring faces to identify a solid attachment anchor point
        BlockPos neighbor = null;
        EnumFacing side = null;

        for (EnumFacing facing : EnumFacing.values()) {
            BlockPos offsetPos = targetPos.func_177972_a(facing);
            if (!mc.field_71441_e.func_175623_d(offsetPos)) {
                neighbor = offsetPos;
                side = facing.func_176734_d();
                break;
            }
        }

        // Downward vertical floor fallback anchor check
        if (neighbor == null) {
            BlockPos below = targetPos.func_177977_b();
            if (!mc.field_71441_e.func_175623_d(below)) {
                neighbor = below;
                side = EnumFacing.UP;
            }
        }

        if (neighbor != null) {
            int originalSlot = mc.field_71439_g.field_71071_by.field_70461_c;

            // 3. STRICT PACKET ROTATIONS: Aim silently at the center block face vector
            if (strictRotations) {
                lookAtBlockFace(neighbor, side);
            }

            // Tower Logic: Fast climbing vertical pillar mechanics
            if (tower && mc.field_71474_y.field_74314_A.func_151470_d() && mc.field_71439_g.field_191988_bg == 0.0f && mc.field_71439_g.field_70701_bs == 0.0f) {
                mc.field_71439_g.field_70159_w = 0.0;
                mc.field_71439_g.field_70179_y = 0.0;
                mc.field_71439_g.field_70181_x = 0.41999998688698; // Precise vanilla jumping metric double
            }

            // Execute ghost-hand swap sequence
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(blockSlot));

            // Interact precisely using offset hit calculations to clear strict raytrace checks
            Vec3d hitVec = new Vec3d(neighbor).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(side.func_176730_m()).func_186678_a(0.5));
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(
                    neighbor, side, EnumHand.MAIN_HAND, (float) hitVec.field_72450_a, (float) hitVec.field_72448_b, (float) hitVec.field_72449_c));
            mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);

            // Revert back to original hotbar held slot instantly
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(originalSlot));
        }
    }

    private int findBlockInHotbar() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (!stack.func_190926_b() && stack.func_77973_b() instanceof ItemBlock) {
                Block block = ((ItemBlock) stack.func_77973_b()).func_179223_d();
                // Avoid placing blocks that break movement structures or trigger accidental GUI screens
                if (block != Blocks.field_150350_a && block != Blocks.field_150335_W && block != Blocks.field_150462_ai
                        && block != Blocks.field_150486_ae && block != Blocks.field_150447_bR && block != Blocks.field_150460_al) {
                    return i;
                }
            }
        }
        return -1;
    }

    private void lookAtBlockFace(BlockPos pos, EnumFacing facing) {
        Vec3d hitVec = new Vec3d(pos).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(facing.func_176730_m()).func_186678_a(0.5));

        double diffX = hitVec.field_72450_a - mc.field_71439_g.field_70165_t;
        double diffY = hitVec.field_72448_b - (mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e());
        double diffZ = hitVec.field_72449_c - mc.field_71439_g.field_70161_v;
        double diffXZ = MathHelper.func_76133_a(diffX * diffX + diffZ * diffZ);

        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(Math.atan2(diffY, diffXZ) * 180.0 / Math.PI);

        float serverYaw = mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z);
        float serverPitch = mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A);
        serverPitch = MathHelper.func_76131_a(serverPitch, -90.0f, 90.0f);

        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(serverYaw, serverPitch, mc.field_71439_g.field_70122_E));
    }

    @Override
    protected void onUpdate() {}
}
