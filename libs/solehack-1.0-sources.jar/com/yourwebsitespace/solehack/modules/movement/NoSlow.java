package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.MovementInput;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.lang.reflect.Field;

public class NoSlow extends Module {

    public static NoSlow INSTANCE;
    private final Minecraft mc = Minecraft.func_71410_x();

    public boolean items = true;
    public boolean soulSand = true;
    public boolean webs = true;

    // Reflection field setup using Forge's ReflectionHelper
    // "isInWeb" = deobfuscated development name, "field_70134_J" = SRG/production name
    private final Field isInWebField = ReflectionHelper.findField(Entity.class, "isInWeb", "field_70134_J");

    public NoSlow() {
        super("NoSlow", Category.MOVEMENT);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    // Bypasses item usage slowdown (eating, drinking, bow, shield)
    @SubscribeEvent
    public void onInputUpdate(InputUpdateEvent event) {
        if (!this.isEnabled() || !items || mc.field_71439_g == null) return;

        if (mc.field_71439_g.func_184587_cr() && !mc.field_71439_g.func_184218_aH()) {
            MovementInput input = event.getMovementInput();
            input.field_78902_a *= 5.0f;
            input.field_192832_b *= 5.0f;
        }
    }

    @Override
    protected void onUpdate() {
        if (!this.isEnabled() || mc.field_71439_g == null || mc.field_71441_e == null) return;

        // Bypasses Cobweb slowdown using Reflection to bypass protected access
        if (webs) {
            try {
                if (isInWebField.getBoolean(mc.field_71439_g)) {
                    isInWebField.setBoolean(mc.field_71439_g, false);
                }
            } catch (Exception ignored) {
                // Safely catches reflection exceptions without crashing
            }
        }

        // Bypasses Soul Sand slowdown
        if (soulSand && mc.field_71441_e.func_180495_p(mc.field_71439_g.func_180425_c()).func_177230_c() == Blocks.field_150425_aM) {
            mc.field_71439_g.field_70159_w *= 2.5D;
            mc.field_71439_g.field_70179_y *= 2.5D;
        }
    }
}