package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Flight extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    public Flight() {
        super("Flight", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        if (mc.field_71439_g == null) return;
        // Allows the player to fly
        mc.field_71439_g.field_71075_bZ.field_75101_c = true;
        mc.field_71439_g.field_71075_bZ.field_75100_b = true;
    }

    @Override
    protected void onUpdate() {

    }

    @Override
    public void onDisable() {
        if (mc.field_71439_g == null) return;
        // Restores normal movement state
        if (!mc.field_71439_g.func_184812_l_() && !mc.field_71439_g.func_175149_v()) {
            mc.field_71439_g.field_71075_bZ.field_75101_c = false;
            mc.field_71439_g.field_71075_bZ.field_75100_b = false;
        }
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (mc.field_71439_g == null || !this.isEnabled()) return;

        // Keeps flight active and sets speed
        mc.field_71439_g.field_71075_bZ.field_75101_c = true;
        mc.field_71439_g.field_71075_bZ.func_75092_a(0.05f);
    }
}
