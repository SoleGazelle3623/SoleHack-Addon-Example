package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class LongJump extends Module {

    protected static final Minecraft mc = Minecraft.func_71410_x();

    public LongJump() {
        super("LongJump", Category.MOVEMENT);
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.PlayerTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        if (mc.field_71439_g.field_70160_al && !mc.field_71439_g.field_70122_E) {
            mc.field_71439_g.field_70181_x += 0.05;

            double boost = 4.0;
            if (mc.field_71439_g.field_71158_b.field_192832_b != 0 || mc.field_71439_g.field_71158_b.field_78902_a != 0) {
                float yaw = mc.field_71439_g.field_70177_z;
                if (mc.field_71439_g.field_71158_b.field_192832_b < 0) yaw += 180;
                if (mc.field_71439_g.field_71158_b.field_78902_a > 0) yaw -= 90;
                if (mc.field_71439_g.field_71158_b.field_78902_a < 0) yaw += 90;

                mc.field_71439_g.field_70159_w = Math.cos(Math.toRadians(yaw + 90)) * boost;
                mc.field_71439_g.field_70179_y = Math.sin(Math.toRadians(yaw + 90)) * boost;
            }
        }
    }

    @Override
    protected void onUpdate() {

    }
}