package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.init.MobEffects;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Strafe extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    public double movementSpeedFactor = 0.2873;
    public boolean autoJump = true;

    public Strafe() {
        super("Strafe", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        if (mc.field_71439_g.field_71158_b.field_192832_b == 0.0f && mc.field_71439_g.field_71158_b.field_78902_a == 0.0f) {
            mc.field_71439_g.field_70159_w = 0.0;
            mc.field_71439_g.field_70179_y = 0.0;
            return;
        }

        // Calculate base speed dynamically accounting for Speed potion effects
        double baseSpeed = 0.2873;
        net.minecraft.potion.PotionEffect speedEffect = mc.field_71439_g.func_70660_b(MobEffects.field_76424_c);
        if (speedEffect != null) {
            int amplifier = speedEffect.func_76458_c();
            baseSpeed *= 1.0 + (amplifier + 1) * 0.2;
        }

        // Handle safe auto-jump logic with strict anti-cheat multipliers
        if (autoJump && mc.field_71439_g.field_70122_E && (mc.field_71439_g.field_71158_b.field_192832_b != 0.0f || mc.field_71439_g.field_71158_b.field_78902_a != 0.0f)) {
            mc.field_71439_g.func_70664_aZ();
            movementSpeedFactor = baseSpeed * 1.583; // Standard vanilla sprint-jump initial boost ratio
        } else {
            movementSpeedFactor = baseSpeed;
        }

        applyStrafeVelocity(movementSpeedFactor);
    }

    private void applyStrafeVelocity(double speed) {
        float forward = mc.field_71439_g.field_71158_b.field_192832_b;
        float strafe = mc.field_71439_g.field_71158_b.field_78902_a;
        float yaw = mc.field_71439_g.field_70177_z;

        if (forward == 0.0f && strafe == 0.0f) {
            mc.field_71439_g.field_70159_w = 0.0;
            mc.field_71439_g.field_70179_y = 0.0;
        } else {
            if (forward != 0.0f) {
                if (strafe > 0.0f) {
                    yaw += (float) (forward > 0.0f ? -45 : 45);
                } else if (strafe < 0.0f) {
                    yaw += (float) (forward > 0.0f ? 45 : -45);
                }
                strafe = 0.0f;
                if (forward > 0.0f) {
                    forward = 1.0f;
                } else if (forward < 0.0f) {
                    forward = -1.0f;
                }
            }

            double cos = Math.cos(Math.toRadians(yaw + 90.0f));
            double sin = Math.sin(Math.toRadians(yaw + 90.0f));

            mc.field_71439_g.field_70159_w = (double) forward * speed * cos + (double) strafe * speed * sin;
            mc.field_71439_g.field_70179_y = (double) forward * speed * sin - (double) strafe * speed * cos;
        }
    }

    @Override
    protected void onUpdate() {}
}