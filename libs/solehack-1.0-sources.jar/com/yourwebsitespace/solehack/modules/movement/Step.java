package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;

public class Step extends Module {

    public static Step INSTANCE;
    private final Minecraft mc = Minecraft.func_71410_x();

    public float height = 1.9f;
    private float oldStepHeight = 0.6f;

    public Step() {
        super("Step", Category.MOVEMENT);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        if (mc.field_71439_g != null) {
            oldStepHeight = mc.field_71439_g.field_70138_W;
            mc.field_71439_g.field_70138_W = height;
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_71439_g != null) {
            mc.field_71439_g.field_70138_W = oldStepHeight;
        }
    }

    @Override
    public void onUpdate() {
        if (mc.field_71439_g == null) return;

        // Keep stepHeight applied if changed by water/effects
        if (mc.field_71439_g.field_70138_W != height) {
            mc.field_71439_g.field_70138_W = height;
        }
    }
}