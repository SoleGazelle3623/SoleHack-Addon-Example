package com.yourwebsitespace.solehack.modules.movement;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Anchor extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // 5b5t Optimization Settings
    public int pitchActivationThreshold = 80; // Only activates if you look down past this angle (prevents unintended pulls)
    public boolean pullForceful = true;       // Increases gravity velocity downward for an instant snap

    public Anchor() {
        super("Anchor", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        // Safety verification: Pause logic if player is flying, swimming, or on a ladder
        if (mc.field_71439_g.field_71075_bZ.field_75100_b || mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab() || mc.field_71439_g.func_70617_f_()) {
            return;
        }

        // Pitch Angle Check: Only engage if the user actively looks down to enter a hole
        if (mc.field_71439_g.field_70125_A < pitchActivationThreshold) {
            return;
        }

        BlockPos playerPos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);

        // Scan downwards up to 3 blocks beneath the player to look for a secure defensive hole layout
        for (int i = 0; i < 3; i++) {
            BlockPos checkPos = playerPos.func_177979_c(i);

            if (isValidHole(checkPos)) {
                // ANCHOR SNAP TRIGGER: Halt all horizontal momentum completely to center the player over the gap
                mc.field_71439_g.field_70159_w = 0.0;
                mc.field_71439_g.field_70179_y = 0.0;

                if (pullForceful) {
                    // Inject a strict downward velocity vector to pull the model down quickly
                    mc.field_71439_g.field_70181_x = -0.6;
                }
                break;
            }
        }
    }

    private boolean isValidHole(BlockPos pos) {
        // The core space of the hole must be empty air
        if (!mc.field_71441_e.func_175623_d(pos) || !mc.field_71441_e.func_175623_d(pos.func_177984_a())) {
            return false;
        }

        // Define the 5 defensive blocks enclosing the hole
        BlockPos[] sides = new BlockPos[] {
                pos.func_177977_b(),
                pos.func_177978_c(),
                pos.func_177968_d(),
                pos.func_177974_f(),
                pos.func_177976_e()
        };

        for (BlockPos side : sides) {
            net.minecraft.block.Block block = mc.field_71441_e.func_180495_p(side).func_177230_c();
            // A defensive hole must be completely enclosed by obsidian or bedrock
            if (block != Blocks.field_150343_Z && block != Blocks.field_150357_h) {
                return false;
            }
        }
        return true;
    }

    @Override
    protected void onUpdate() {}
}
