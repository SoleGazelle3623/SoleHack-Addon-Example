package com.yourwebsitespace.solehack.modules.combat;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.block.Block;
import net.minecraft.block.BlockShulkerBox;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.ContainerHopper;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Auto32k extends Module {

    public static Auto32k INSTANCE;
    private final Minecraft mc = Minecraft.func_71410_x();

    private boolean isPlacing = false;

    public Auto32k() {
        super("Auto32k", Category.COMBAT);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
        isPlacing = false;

        if (mc.field_71439_g == null || mc.field_71441_e == null) return;

        int hopperSlot = findBlockSlot(Blocks.field_150438_bZ);
        int shulkerSlot = findShulkerSlot();

        if (hopperSlot == -1 || shulkerSlot == -1) {
            this.setEnabled(false);
            return;
        }

        RayTraceResult ray = mc.field_71476_x;
        if (ray == null || ray.field_72313_a != RayTraceResult.Type.BLOCK) {
            this.setEnabled(false);
            return;
        }

        BlockPos targetPos = ray.func_178782_a();
        EnumFacing side = ray.field_178784_b;

        BlockPos hopperPos = targetPos.func_177972_a(side);
        BlockPos shulkerPos = hopperPos.func_177984_a();

        if (!mc.field_71441_e.func_180495_p(hopperPos).func_185904_a().func_76222_j() ||
                !mc.field_71441_e.func_180495_p(shulkerPos).func_185904_a().func_76222_j()) {
            this.setEnabled(false);
            return;
        }

        // 1. Place Hopper
        placeBlock(hopperPos, hopperSlot, side.func_176734_d());

        // 2. Place Shulker Box on top of Hopper
        placeBlock(shulkerPos, shulkerSlot, EnumFacing.DOWN);

        // 3. Open Hopper
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(
                hopperPos, EnumFacing.UP, EnumHand.MAIN_HAND, 0.5f, 0.5f, 0.5f));

        isPlacing = true;
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        isPlacing = false;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || !isPlacing) return;

        // Container Check: Detects if a hopper inventory container is active
        if (mc.field_71439_g.field_71070_bA instanceof ContainerHopper) {
            ContainerHopper hopperContainer = (ContainerHopper) mc.field_71439_g.field_71070_bA;

            // Loop through the 5 hopper slots (slots 0 to 4)
            for (int i = 0; i < 5; i++) {
                ItemStack stack = hopperContainer.func_75139_a(i).func_75211_c();

                if (!stack.func_190926_b() && stack.func_77973_b() != Items.field_190931_a) {
                    // SWAP slot i with Hotbar slot 0 (index 36 in openContainer indexing)
                    mc.field_71442_b.func_187098_a(
                            hopperContainer.field_75152_c,
                            i,
                            0, // Hotbar slot target index (0 = slot 1)
                            ClickType.SWAP,
                            mc.field_71439_g
                    );

                    // Switch main hand to Hotbar slot 0
                    mc.field_71439_g.field_71071_by.field_70461_c = 0;
                    mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(0));

                    this.setEnabled(false);
                    return;
                }
            }
        }
    }

    private void placeBlock(BlockPos pos, int slot, EnumFacing facing) {
        int oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(slot));

        Vec3d hitVec = new Vec3d(pos).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(facing.func_176730_m()).func_186678_a(0.5));
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(
                pos.func_177972_a(facing), facing.func_176734_d(), EnumHand.MAIN_HAND,
                (float) hitVec.field_72450_a, (float) hitVec.field_72448_b, (float) hitVec.field_72449_c));

        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(oldSlot));
    }

    private int findBlockSlot(Block block) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack.func_77973_b() instanceof ItemBlock && ((ItemBlock) stack.func_77973_b()).func_179223_d() == block) {
                return i;
            }
        }
        return -1;
    }

    private int findShulkerSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack.func_77973_b() instanceof ItemBlock) {
                Block block = ((ItemBlock) stack.func_77973_b()).func_179223_d();
                if (block instanceof BlockShulkerBox) {
                    return i;
                }
            }
        }
        return -1;
    }

    @Override
    protected void onUpdate() {}
}