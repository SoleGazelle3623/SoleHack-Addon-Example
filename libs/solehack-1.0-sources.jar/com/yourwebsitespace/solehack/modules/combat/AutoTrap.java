package com.yourwebsitespace.solehack.modules.combat;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.block.BlockObsidian;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AutoTrap extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    public double range = 5.0;
    public int blocksPerTick = 4;

    public AutoTrap() {
        super("AutoTrap", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        EntityPlayer target = findTarget();
        if (target == null) {
            return;
        }

        int obbySlot = findObsidianSlot();
        if (obbySlot == -1) {
            return; // Out of obsidian in hotbar
        }

        int placed = 0;
        BlockPos targetPos = new BlockPos(target.func_174791_d());

        // Standard trap offset positions relative to the target player's feet/head
        BlockPos[] trapOffsets = {
                targetPos.func_177982_a(0, 2, 0), // Head block cover
                targetPos.func_177982_a(1, 1, 0),
                targetPos.func_177982_a(-1, 1, 0),
                targetPos.func_177982_a(0, 1, 1),
                targetPos.func_177982_a(0, 1, -1)
        };

        int currentSlot = mc.field_71439_g.field_71071_by.field_70461_c;

        for (BlockPos pos : trapOffsets) {
            if (placed >= blocksPerTick) break;

            if (mc.field_71441_e.func_180495_p(pos).func_177230_c().func_176200_f(mc.field_71441_e, pos)) {
                if (mc.field_71439_g.func_174818_b(pos) <= range * range) {
                    placeBlock(pos, obbySlot, currentSlot);
                    placed++;
                }
            }
        }
    }

    private EntityPlayer findTarget() {
        EntityPlayer closest = null;
        double maxDist = range * range;

        for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
            if (player == mc.field_71439_g || player.field_70128_L || player.func_110143_aJ() <= 0.0f) continue;
            double dist = mc.field_71439_g.func_70068_e(player);
            if (dist < maxDist) {
                maxDist = dist;
                closest = player;
            }
        }
        return closest;
    }

    private int findObsidianSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (!stack.func_190926_b() && stack.func_77973_b() instanceof ItemBlock) {
                if (((ItemBlock) stack.func_77973_b()).func_179223_d() instanceof BlockObsidian) {
                    return i;
                }
            }
        }
        return -1;
    }

    private void placeBlock(BlockPos pos, int obbySlot, int originalSlot) {
        // Quick packet hotbar switch
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(obbySlot));

        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(
                pos.func_177977_b(), EnumFacing.UP, EnumHand.MAIN_HAND, 0.5f, 1.0f, 0.5f
        ));
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketAnimation(EnumHand.MAIN_HAND));

        // Revert hotbar index slot back
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(originalSlot));
    }

    @Override
    protected void onUpdate() {}
}