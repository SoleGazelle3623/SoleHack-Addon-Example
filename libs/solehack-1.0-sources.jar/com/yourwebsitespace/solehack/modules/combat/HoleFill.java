package com.yourwebsitespace.solehack.modules.combat;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HoleFill extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    public double range = 5.0;
    public boolean strictRotations = true;
    public boolean smart = true; // Only fill holes near targets

    public HoleFill() {
        super("HoleFill", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) return;
        if (!this.isEnabled()) return;

        int obsidianSlot = findObsidianSlot();
        if (obsidianSlot == -1) return;

        BlockPos targetHole = findBestHole();
        if (targetHole != null) {
            fillHole(targetHole, obsidianSlot);
        }
    }

    private int findObsidianSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack.func_77973_b() instanceof ItemBlock && ((ItemBlock) stack.func_77973_b()).func_179223_d() == Blocks.field_150343_Z) {
                return i;
            }
        }
        return -1;
    }

    private BlockPos findBestHole() {
        List<BlockPos> holes = new ArrayList<>();
        BlockPos playerPos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);

        int rad = (int) Math.ceil(range);
        for (int x = -rad; x <= rad; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -rad; z <= rad; z++) {
                    BlockPos pos = playerPos.func_177982_a(x, y, z);

                    if (mc.field_71439_g.func_174818_b(pos) > range * range) continue;

                    if (isHole(pos)) {
                        if (smart) {
                            boolean enemyNearby = mc.field_71441_e.field_73010_i.stream()
                                    .anyMatch(p -> p != mc.field_71439_g && !p.field_70128_L && p.func_174818_b(pos) <= 4.0);
                            if (!enemyNearby) continue;
                        }
                        holes.add(pos);
                    }
                }
            }
        }

        return holes.stream()
                .min(Comparator.comparingDouble(pos -> mc.field_71439_g.func_174818_b(pos)))
                .orElse(null);
    }

    private boolean isHole(BlockPos pos) {
        if (mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150350_a) return false;
        if (!mc.field_71441_e.func_175623_d(pos.func_177984_a())) return false;

        BlockPos down = pos.func_177977_b();
        return (mc.field_71441_e.func_180495_p(down).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(down).func_177230_c() == Blocks.field_150357_h) &&
                (mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h) &&
                (mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h) &&
                (mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h) &&
                (mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h);
    }

    private void fillHole(BlockPos pos, int slot) {
        int currentItem = mc.field_71439_g.field_71071_by.field_70461_c;

        if (strictRotations) {
            lookAtVector(new Vec3d(pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.5, pos.func_177952_p() + 0.5));
        }

        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(slot));
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(
                pos.func_177977_b(), EnumFacing.UP, EnumHand.MAIN_HAND, 0.5f, 1.0f, 0.5f));
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(currentItem));
        mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
    }

    private void lookAtVector(Vec3d targetVec) {
        double diffX = targetVec.field_72450_a - mc.field_71439_g.field_70165_t;
        double diffY = targetVec.field_72448_b - (mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e());
        double diffZ = targetVec.field_72449_c - mc.field_71439_g.field_70161_v;
        double diffXZ = MathHelper.func_76133_a(diffX * diffX + diffZ * diffZ);

        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(Math.atan2(diffY, diffXZ) * 180.0 / Math.PI);

        float serverYaw = mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z);
        float serverPitch = mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A);
        serverPitch = MathHelper.func_76131_a(serverPitch, -90.0f, 90.0f);

        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(serverYaw, serverPitch, mc.field_71439_g.field_70122_E));
    }

    @Override
    protected void onUpdate() {}
}