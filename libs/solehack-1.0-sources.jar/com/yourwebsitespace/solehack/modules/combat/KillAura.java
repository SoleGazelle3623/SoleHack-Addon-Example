package com.yourwebsitespace.solehack.modules.combat;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.Comparator;

public class KillAura extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // 5b5t optimized targeting thresholds
    public double range = 4.2;        // Reach parameter threshold limit
    public double wallsRange = 3.0;   // Reach boundary if target is behind walls
    public long hitDelayMs = 625;      // High-speed CPS trigger throttle rate (approx. 11-12 CPS)
    public boolean strictRotations = true;

    private long lastHitTime = 0L;
    private EntityPlayer currentTarget = null;

    public KillAura() {
        super("KillAura", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
        currentTarget = null;
        lastHitTime = 0L;
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        currentTarget = null;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            currentTarget = null;
            return;
        }

        // Find the best valid target player closest to us
        currentTarget = getClosestTarget();
        if (currentTarget == null) {
            return;
        }

        long currentTime = System.currentTimeMillis();

        // High-Precision hardware timer execution throttle
        if (currentTime - lastHitTime >= hitDelayMs) {

            // Send silent rotation look vector update packets right before swinging
            if (strictRotations) {
                lookAtEntityCenter(currentTarget);
            }

            // Dispatch raw attack packet sequence to the server stream
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketUseEntity(currentTarget));
            mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);

            lastHitTime = currentTime;
        }
    }

    private EntityPlayer getClosestTarget() {
        return mc.field_71441_e.field_73010_i.stream()
                .filter(player -> player != mc.field_71439_g && !player.field_70128_L && player.func_110143_aJ() > 0)
                .filter(player -> {
                    // Filter targets cleanly based on whether we can physically see them or not
                    double reach = mc.field_71439_g.func_70685_l(player) ? range : wallsRange;
                    return mc.field_71439_g.func_70032_d(player) <= reach;
                })
                .min(Comparator.comparingDouble(player -> mc.field_71439_g.func_70032_d(player)))
                .orElse(null);
    }

    private void lookAtEntityCenter(EntityPlayer target) {
        // Targets the physical center point location of the target player's hitbox bounding grid
        Vec3d targetVec = new Vec3d(
                target.field_70165_t,
                target.field_70163_u + (target.func_70047_e() / 2.0),
                target.field_70161_v
        );

        double diffX = targetVec.field_72450_a - mc.field_71439_g.field_70165_t;
        double diffY = targetVec.field_72448_b - (mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e());
        double diffZ = targetVec.field_72449_c - mc.field_71439_g.field_70161_v;
        double diffXZ = MathHelper.func_76133_a(diffX * diffX + diffZ * diffZ);

        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(Math.atan2(diffY, diffXZ) * 180.0 / Math.PI);

        float serverYaw = mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z);
        float serverPitch = mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A);
        serverPitch = MathHelper.func_76131_a(serverPitch, -90.0f, 90.0f);

        // Dispatches the direct rotation data fields straight down the network pipe
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(serverYaw, serverPitch, mc.field_71439_g.field_70122_E));
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || currentTarget == null || !this.isEnabled()) {
            return;
        }

        // Generate full 3D Box ESP highlights around our active combat target tracking bounding box coordinates
        double renderX = currentTarget.field_70142_S + (currentTarget.field_70165_t - currentTarget.field_70142_S) * event.getPartialTicks() - mc.func_175598_ae().field_78730_l;
        double renderY = currentTarget.field_70137_T + (currentTarget.field_70163_u - currentTarget.field_70137_T) * event.getPartialTicks() - mc.func_175598_ae().field_78731_m;
        double renderZ = currentTarget.field_70136_U + (currentTarget.field_70161_v - currentTarget.field_70136_U) * event.getPartialTicks() - mc.func_175598_ae().field_78728_n;

        AxisAlignedBB bb = new AxisAlignedBB(
                renderX - currentTarget.field_70130_N / 2.0, renderY, renderZ - currentTarget.field_70130_N / 2.0,
                renderX + currentTarget.field_70130_N / 2.0, renderY + currentTarget.field_70131_O, renderZ + currentTarget.field_70130_N / 2.0
        );

        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(2.0f);

        // Render clear semi-transparent red status block box highlights
        RenderGlobal.func_189696_b(bb, 1.0f, 0.0f, 0.0f, 0.15f);
        RenderGlobal.func_189697_a(bb, 1.0f, 0.0f, 0.0f, 0.8f);

        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179126_j();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    @Override
    protected void onUpdate() {}
}
