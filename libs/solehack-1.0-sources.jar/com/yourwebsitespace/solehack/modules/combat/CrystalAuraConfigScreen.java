package com.yourwebsitespace.solehack.modules.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.MathHelper;

import javax.annotation.Nonnull;
import java.io.IOException;

public class CrystalAuraConfigScreen extends GuiScreen {

    private final GuiScreen parent;

    // Element IDs
    private static final int BUTTON_DONE = 999;
    private static final int SLIDER_RANGE = 0;
    private static final int SLIDER_WALLS_RANGE = 1;
    private static final int SLIDER_PLACE_DELAY = 5;
    private static final int SLIDER_BREAK_DELAY = 6;
    private static final int TOGGLE_ROTATIONS = 2;
    private static final int TOGGLE_PROTOCOL13 = 3;
    private static final int TOGGLE_SILENT = 4;

    public CrystalAuraConfigScreen(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public void func_73866_w_() {
        this.field_146292_n.clear();
        int centerX = this.field_146294_l / 2;
        int startY = 30;

        CrystalAura module = CrystalAura.INSTANCE;
        if (module == null) return;

        // Custom Sliders for Ranges and Delays
        this.field_146292_n.add(new GuiSlider(SLIDER_RANGE, centerX - 100, startY, "Range: ", 1.0f, 6.0f, (float) module.range));
        this.field_146292_n.add(new GuiSlider(SLIDER_WALLS_RANGE, centerX - 100, startY + 24, "Walls Range: ", 1.0f, 6.0f, (float) module.wallsRange));
        this.field_146292_n.add(new GuiSlider(SLIDER_PLACE_DELAY, centerX - 100, startY + 48, "Place Delay (ms): ", 0.0f, 1000.0f, module.placeDelay));
        this.field_146292_n.add(new GuiSlider(SLIDER_BREAK_DELAY, centerX - 100, startY + 72, "Break Delay (ms): ", 0.0f, 1000.0f, module.breakDelay));

        // Toggle Buttons (Shifted down to accommodate new sliders)
        this.field_146292_n.add(new GuiButton(TOGGLE_ROTATIONS, centerX - 100, startY + 106, 200, 20, "Strict Rotations: " + (module.strictRotations ? "ON" : "OFF")));
        this.field_146292_n.add(new GuiButton(TOGGLE_PROTOCOL13, centerX - 100, startY + 130, 200, 20, "1.13 Placement (protocol13): " + (module.protocol13 ? "ON" : "OFF")));
        this.field_146292_n.add(new GuiButton(TOGGLE_SILENT, centerX - 100, startY + 154, 200, 20, "Silent Switch: " + (module.silentSwitch ? "ON" : "OFF")));

        // Close Button
        this.field_146292_n.add(new GuiButton(BUTTON_DONE, centerX - 100, this.field_146295_m - 35, 200, 20, "Done"));
    }

    @Override
    protected void func_146284_a(@Nonnull GuiButton button) throws IOException {
        if (button.field_146127_k == BUTTON_DONE) {
            this.field_146297_k.func_147108_a(parent);
            return;
        }

        CrystalAura module = CrystalAura.INSTANCE;
        if (module == null) return;

        if (button.field_146127_k == TOGGLE_ROTATIONS) {
            module.strictRotations = !module.strictRotations;
            button.field_146126_j = "Strict Rotations: " + (module.strictRotations ? "ON" : "OFF");
        }
        if (button.field_146127_k == TOGGLE_PROTOCOL13) {
            module.protocol13 = !module.protocol13;
            button.field_146126_j = "1.13 Placement (protocol13): " + (module.protocol13 ? "ON" : "OFF");
        }
        if (button.field_146127_k == TOGGLE_SILENT) {
            module.silentSwitch = !module.silentSwitch;
            button.field_146126_j = "Silent Switch: " + (module.silentSwitch ? "ON" : "OFF");
        }
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);
        updateModuleValues();
    }

    @Override
    protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        super.func_146273_a(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
        updateModuleValues();
    }

    private void updateModuleValues() {
        CrystalAura module = CrystalAura.INSTANCE;
        if (module == null) return;

        for (GuiButton button : this.field_146292_n) {
            if (button instanceof GuiSlider) {
                GuiSlider slider = (GuiSlider) button;
                if (slider.field_146127_k == SLIDER_RANGE) module.range = slider.getValue();
                if (slider.field_146127_k == SLIDER_WALLS_RANGE) module.wallsRange = slider.getValue();
                if (slider.field_146127_k == SLIDER_PLACE_DELAY) module.placeDelay = (int) slider.getValue();
                if (slider.field_146127_k == SLIDER_BREAK_DELAY) module.breakDelay = (int) slider.getValue();
            }
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);

        String title = (CrystalAura.INSTANCE != null) ? CrystalAura.INSTANCE.getName() + " Configuration" : "CrystalAura Configuration";
        this.func_73732_a(this.field_146289_q, title, this.field_146294_l / 2, 12, 0xFFFFFF);
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }

    private static class GuiSlider extends GuiButton {
        private final String prefix;
        private final float min;
        private final float max;
        private float sliderValue;
        private boolean dragging = false;

        public GuiSlider(int id, int x, int y, String prefix, float min, float max, float current) {
            super(id, x, y, 200, 20, "");
            this.prefix = prefix;
            this.min = min;
            this.max = max;
            this.sliderValue = (current - min) / (max - min);

            // Format whole numbers cleanly if min/max imply millisecond counts (integers)
            if (max > 10.0f) {
                this.field_146126_j = prefix + (int) getActualValue();
            } else {
                this.field_146126_j = prefix + String.format("%.1f", getActualValue());
            }
        }

        public float getValue() {
            return getActualValue();
        }

        private float getActualValue() {
            return min + (sliderValue * (max - min));
        }

        @Override
        protected int func_146114_a(boolean mouseOver) {
            return 0;
        }

        @Override
        protected void func_146119_b(@Nonnull Minecraft mcInstance, int mouseX, int mouseY) {
            if (this.field_146125_m) {
                if (this.dragging) {
                    this.sliderValue = (float) (mouseX - (this.field_146128_h + 4)) / (float) (this.field_146120_f - 8);
                    this.sliderValue = MathHelper.func_76131_a(this.sliderValue, 0.0f, 1.0f);

                    if (max > 10.0f) {
                        this.field_146126_j = prefix + (int) getActualValue();
                    } else {
                        this.field_146126_j = prefix + String.format("%.1f", getActualValue());
                    }
                }

                mcInstance.func_110434_K().func_110577_a(field_146122_a);
                GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
                this.func_73729_b(this.field_146128_h + (int) (this.sliderValue * (this.field_146120_f - 8)), this.field_146129_i, 0, 66, 4, 20);
                this.func_73729_b(this.field_146128_h + (int) (this.sliderValue * (this.field_146120_f - 8)) + 4, this.field_146129_i, 196, 66, 4, 20);
            }
        }

        @Override
        public boolean func_146116_c(@Nonnull Minecraft mcInstance, int mouseX, int mouseY) {
            if (super.func_146116_c(mcInstance, mouseX, mouseY)) {
                this.sliderValue = (float) (mouseX - (this.field_146128_h + 4)) / (float) (this.field_146120_f - 8);
                this.sliderValue = MathHelper.func_76131_a(this.sliderValue, 0.0f, 1.0f);

                if (max > 10.0f) {
                    this.field_146126_j = prefix + (int) getActualValue();
                } else {
                    this.field_146126_j = prefix + String.format("%.1f", getActualValue());
                }

                this.dragging = true;
                return true;
            }
            return false;
        }

        @Override
        public void func_146118_a(int mouseX, int mouseY) {
            this.dragging = false;
        }
    }
}