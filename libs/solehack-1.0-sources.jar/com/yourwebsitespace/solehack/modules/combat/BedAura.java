package com.yourwebsitespace.solehack.modules.combat;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBed;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBed;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.Comparator;

public class BedAura extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // 5b5t Automated Combat Configuration Profiles
    public double range = 5.0;
    public boolean strictRotations = true;
    public long explodedelayMs = 80;

    private long lastExplodeTime = 0L;

    // Coordinates cached for the active render tracking pass
    private BlockPos renderPos = null;
    private EnumFacing renderFacing = EnumFacing.NORTH;

    public BedAura() {
        super("BedAura", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
        lastExplodeTime = 0L;
        renderPos = null;
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        renderPos = null;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            renderPos = null;
            return;
        }

        if (mc.field_71439_g.field_71093_bK == 0) {
            renderPos = null;
            return;
        }

        EntityPlayer target = getClosestTarget();
        if (target == null) {
            renderPos = null;
            return;
        }

        long currentTime = System.currentTimeMillis();
        if (currentTime - lastExplodeTime < explodedelayMs) {
            return;
        }

        if (explodeExistingBeds()) {
            lastExplodeTime = currentTime;
            return;
        }

        if (placeBedNearTarget(target)) {
            lastExplodeTime = currentTime;
        }
    }

    private EntityPlayer getClosestTarget() {
        return mc.field_71441_e.field_73010_i.stream()
                .filter(player -> player != mc.field_71439_g && !player.field_70128_L && player.func_110143_aJ() > 0)
                .filter(player -> mc.field_71439_g.func_70032_d(player) <= range)
                .min(Comparator.comparingDouble(player -> mc.field_71439_g.func_70032_d(player)))
                .orElse(null);
    }

    private boolean explodeExistingBeds() {
        for (TileEntity tile : mc.field_71441_e.field_147482_g) {
            if (tile instanceof TileEntityBed) {
                BlockPos bedPos = tile.func_174877_v();
                if (mc.field_71439_g.func_174831_c(bedPos) <= range * range) {

                    if (strictRotations) {
                        lookAtVector(new Vec3d(bedPos.func_177958_n() + 0.5, bedPos.func_177956_o() + 0.5, bedPos.func_177952_p() + 0.5));
                    }

                    mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(
                            bedPos, EnumFacing.UP, EnumHand.MAIN_HAND, 0.5f, 0.5f, 0.5f));
                    return true;
                }
            }
        }
        return false;
    }

    private boolean placeBedNearTarget(EntityPlayer target) {
        int bedSlot = findBedSlot();
        if (bedSlot == -1) return false;

        // FIXED: Explicitly anchors tracking calculations to the target's grounding plane vector coordinate [5b5t.org]
        BlockPos targetFeetPos = new BlockPos(Math.floor(target.field_70165_t), Math.floor(target.field_70163_u), Math.floor(target.field_70161_v));
        BlockPos placePos = null;
        EnumFacing placeFacing = EnumFacing.NORTH;
        double bestPlacementDistance = Double.MAX_VALUE;

        // GROUND HORIZONTAL MATRIX SCANNER: Sweeps the surrounding floor layout up to 3 blocks away [5b5t.org]
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                // Adjust for uneven block elevations (-1 block depth to accommodate half slabs or steps) [5b5t.org]
                for (int y = -1; y <= 1; y++) {
                    BlockPos floorCandidate = targetFeetPos.func_177982_a(x, y, z);

                    // Validate that the target space is open air, but rests strictly on a solid block surface [5b5t.org]
                    if (mc.field_71441_e.func_175623_d(floorCandidate) && !mc.field_71441_e.func_175623_d(floorCandidate.func_177977_b())) {
                        double localPlayerDistSq = mc.field_71439_g.func_174831_c(floorCandidate);

                        // Verify the floor candidate block is within your overall reach constraints [5b5t.org]
                        if (localPlayerDistSq <= range * range) {

                            // Check all four cardinal placement facings to find the path closest to the target player model
                            for (EnumFacing facing : EnumFacing.field_176754_o) {
                                BlockPos footSegmentPos = floorCandidate.func_177972_a(facing);

                                // A bed takes 2 horizontal blocks. Verify the second structural block space is also open air! [5b5t.org]
                                if (mc.field_71441_e.func_175623_d(footSegmentPos)) {
                                    double targetDistance = target.func_174831_c(floorCandidate);

                                    if (targetDistance < bestPlacementDistance) {
                                        bestPlacementDistance = targetDistance;
                                        placePos = floorCandidate;
                                        placeFacing = facing;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (placePos != null) {
            int currentSlot = mc.field_71439_g.field_71071_by.field_70461_c;
            BlockPos supportBlock = placePos.func_177977_b();

            if (strictRotations) {
                lookAtVector(new Vec3d(supportBlock.func_177958_n() + 0.5, supportBlock.func_177956_o() + 1.0, supportBlock.func_177952_p() + 0.5));
            }

            // Cache vectors securely to process the 3D ESP outline pass
            renderPos = placePos;
            renderFacing = placeFacing;

            // Ghost hand hotbar packet swap pipeline
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(bedSlot));
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(
                    supportBlock, EnumFacing.UP, EnumHand.MAIN_HAND, 0.5f, 1.0f, 0.5f));
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(currentSlot));

            mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            return true;
        }

        return false;
    }

    private int findBedSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (!stack.func_190926_b() && stack.func_77973_b() instanceof ItemBed) {
                return i;
            }
        }
        return -1;
    }

    private void lookAtVector(Vec3d targetVec) {
        double diffX = targetVec.field_72450_a - mc.field_71439_g.field_70165_t;
        double diffY = targetVec.field_72448_b - (mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e());
        double diffZ = targetVec.field_72449_c - mc.field_71439_g.field_70161_v;
        double diffXZ = MathHelper.func_76133_a(diffX * diffX + diffZ * diffZ);

        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(Math.atan2(diffY, diffXZ) * 180.0 / Math.PI);

        float serverYaw = mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z);
        float serverPitch = mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A);
        serverPitch = MathHelper.func_76131_a(serverPitch, -90.0f, 90.0f);

        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(serverYaw, serverPitch, mc.field_71439_g.field_70122_E));
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || renderPos == null || !this.isEnabled()) {
            return;
        }

        double renderX = renderPos.func_177958_n() - mc.func_175598_ae().field_78730_l;
        double renderY = renderPos.func_177956_o() - mc.func_175598_ae().field_78731_m;
        double renderZ = renderPos.func_177952_p() - mc.func_175598_ae().field_78728_n;

        double footX = renderX + renderFacing.func_176730_m().func_177958_n();
        double footZ = renderZ + renderFacing.func_176730_m().func_177952_p();

        double minX = Math.min(renderX, footX);
        double maxX = Math.max(renderX, footX) + 1.0;
        double minZ = Math.min(renderZ, footZ);
        double maxZ = Math.max(renderZ, footZ) + 1.0;

        AxisAlignedBB bedBoxBB = new AxisAlignedBB(minX, renderY, minZ, maxX, renderY + 0.5625, maxZ);

        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(2.0f);
        RenderGlobal.func_189696_b(bedBoxBB, 1.0f, 0.2f, 0.2f, 0.15f);
        RenderGlobal.func_189697_a(bedBoxBB, 1.0f, 0.2f, 0.2f, 0.8f);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179126_j();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }
    @Override
    protected void onUpdate() {}
}
