package com.yourwebsitespace.solehack.modules.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.MathHelper;

import javax.annotation.Nonnull;

public class BedAuraConfigScreen extends GuiScreen {

    private final GuiScreen parent;
    private final BedAura module;

    // Element IDs
    private final int BUTTON_DONE = 999;
    private final int SLIDER_RANGE = 0;
    private final int SLIDER_EXPLODE_DELAY = 1;
    private final int TOGGLE_ROTATIONS = 2;

    public BedAuraConfigScreen(GuiScreen parent, BedAura module) {
        this.parent = parent;
        this.module = module;
    }

    @Override
    public void func_73866_w_() {
        this.field_146292_n.clear();
        int centerX = this.field_146294_l / 2;
        int startY = 55;

        // --- Column 1: Targeting Options (Left Side) ---
        int leftColX = centerX - 155;
        this.field_146292_n.add(new GuiSlider(SLIDER_RANGE, leftColX, startY, "Reach Range: ", 1.0f, 6.0f, (float) module.range));
        this.field_146292_n.add(new GuiButton(TOGGLE_ROTATIONS, leftColX, startY + 26, 150, 20, "Strict Rotations: " + (module.strictRotations ? "ON" : "OFF")));

        // --- Column 2: Performance Options (Right Side) ---
        int rightColX = centerX + 5;
        this.field_146292_n.add(new GuiSlider(SLIDER_EXPLODE_DELAY, rightColX, startY, "Explode Delay (ms): ", 0.0f, 500.0f, (float) module.explodedelayMs));

        // Main Navigation Close Button
        this.field_146292_n.add(new GuiButton(BUTTON_DONE, centerX - 100, this.field_146295_m - 35, 200, 20, "Apply Settings"));
    }

    @Override
    protected void func_146284_a(@Nonnull GuiButton button) {
        if (button.field_146127_k == BUTTON_DONE) {
            this.field_146297_k.func_147108_a(parent);
            return;
        }

        if (button.field_146127_k == TOGGLE_ROTATIONS) {
            module.strictRotations = !module.strictRotations;
            button.field_146126_j = "Strict Rotations: " + (module.strictRotations ? "ON" : "OFF");
        }
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws java.io.IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);
        updateModuleValues();
    }

    @Override
    protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        super.func_146273_a(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
        updateModuleValues();
    }

    private void updateModuleValues() {
        for (GuiButton button : this.field_146292_n) {
            if (button instanceof GuiSlider) {
                GuiSlider slider = (GuiSlider) button;
                if (slider.field_146127_k == SLIDER_RANGE) module.range = slider.getValue();
                if (slider.field_146127_k == SLIDER_EXPLODE_DELAY) module.explodedelayMs = (long) slider.getValue();
            }
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);

        int centerX = this.field_146294_l / 2;

        // Main Title Header
        this.func_73732_a(this.field_146289_q, "SoleHack - BedAura Configuration Panel", centerX, 15, 0xFF5555);

        // Column Category Labels
        this.func_73731_b(this.field_146289_q, "Targeting Matrix", centerX - 155, 42, 0xAAAAAA);
        this.func_73731_b(this.field_146289_q, "Speed Calibration", centerX + 5, 42, 0xAAAAAA);

        // Live Performance Summary Box Overlay
        int summaryY = 115;
        GuiScreen.func_73734_a(centerX - 155, summaryY, centerX + 155, summaryY + 45, 0x44000000);
        this.func_73731_b(this.field_146289_q, "Active Explosive Profile Summary:", centerX - 145, summaryY + 6, 0xFFFF55);
        this.func_73731_b(this.field_146289_q, "Target Engagement Limit: " + String.format("%.2f blocks", module.range), centerX - 145, summaryY + 20, 0xFFFFFF);
        this.func_73731_b(this.field_146289_q, "Sequence Fire Rate Cooldown: " + module.explodedelayMs + " ms", centerX - 145, summaryY + 32, 0xFFFFFF);
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }

    private static class GuiSlider extends GuiButton {
        private final String prefix;
        private final float min;
        private final float max;
        private float sliderValue;
        private boolean dragging = false;

        public GuiSlider(int id, int x, int y, String prefix, float min, float max, float current) {
            super(id, x, y, 150, 20, "");
            this.prefix = prefix;
            this.min = min;
            this.max = max;
            this.sliderValue = (current - min) / (max - min);
            this.field_146126_j = prefix + String.format("%.1f", getActualValue());
        }

        public float getValue() {
            return getActualValue();
        }

        private float getActualValue() {
            return min + (sliderValue * (max - min));
        }

        @Override
        protected int func_146114_a(boolean mouseOver) {
            return 0;
        }

        // FIXED: Added @Nonnull annotation tags to perfectly pass strict project lint profiles
        @Override
        protected void func_146119_b(@Nonnull Minecraft mcIn, int mouseX, int mouseY) {
            if (this.field_146125_m) {
                if (this.dragging) {
                    this.sliderValue = (float) (mouseX - (this.field_146128_h + 4)) / (float) (this.field_146120_f - 8);
                    this.sliderValue = MathHelper.func_76131_a(this.sliderValue, 0.0f, 1.0f);
                    this.field_146126_j = prefix + String.format("%.1f", getActualValue());
                }

                mcIn.func_110434_K().func_110577_a(field_146122_a);
                GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
                this.func_73729_b(this.field_146128_h + (int) (this.sliderValue * (this.field_146120_f - 8)), this.field_146129_i, 0, 66, 4, 20);
                this.func_73729_b(this.field_146128_h + (int) (this.sliderValue * (this.field_146120_f - 8)) + 4, this.field_146129_i, 196, 66, 4, 20);
            }
        }

        // FIXED: Added @Nonnull annotation tags to perfectly pass strict project lint profiles
        @Override
        public boolean func_146116_c(@Nonnull Minecraft mcIn, int mouseX, int mouseY) {
            if (super.func_146116_c(mcIn, mouseX, mouseY)) {
                this.sliderValue = (float) (mouseX - (this.field_146128_h + 4)) / (float) (this.field_146120_f - 8);
                this.sliderValue = MathHelper.func_76131_a(this.sliderValue, 0.0f, 1.0f);
                this.field_146126_j = prefix + String.format("%.1f", getActualValue());
                this.dragging = true;
                return true;
            }
            return false;
        }

        @Override
        public void func_146118_a(int mouseX, int mouseY) {
            this.dragging = false;
        }
    }
}
