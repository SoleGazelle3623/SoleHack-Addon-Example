package com.yourwebsitespace.solehack.modules.combat;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class Surround extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // 5b5t Optimized Speed Profile settings
    public int blocksPerTick = 2;       // Maximum blocks to place in 1 tick (prevents server packet kicks)
    public boolean strictRotations = true;
    public boolean autoDisable = true;  // Automatically turns off once the surrounding cage is full

    public Surround() {
        super("Surround", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);

        // AUTO-CENTER LOGIC: Executes immediately upon enabling the module
        if (mc.field_71439_g != null && mc.field_71441_e != null) {
            autoCenter();
        }
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    private void autoCenter() {
        // Find the absolute integer base position of the block the player is standing on
        double centerX = MathHelper.func_76128_c(mc.field_71439_g.field_70165_t) + 0.5;
        double centerZ = MathHelper.func_76128_c(mc.field_71439_g.field_70161_v) + 0.5;

        // Keep the exact current vertical position to avoid illegal height flags
        double posY = mc.field_71439_g.field_70163_u;

        // Spoof the center alignment position to the server instantly
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(centerX, posY, centerZ, mc.field_71439_g.field_70122_E));

        // Snap the local player position to match the centered coordinates
        mc.field_71439_g.func_70107_b(centerX, posY, centerZ);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        int obsidianSlot = findObsidianSlot();
        if (obsidianSlot == -1) {
            if (autoDisable) this.setEnabled(false);
            return; // Out of obsidian blocks
        }

        // Get the player's exact underlying floor block coordinate position
        BlockPos playerPos = new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v));

        // Define the 4 cardinal directions enclosing the feet layer matrix space
        BlockPos[] surroundTargets = new BlockPos[] {
                playerPos.func_177978_c(),
                playerPos.func_177968_d(),
                playerPos.func_177974_f(),
                playerPos.func_177976_e()
        };

        int blocksPlacedThisTick = 0;
        int currentSlot = mc.field_71439_g.field_71071_by.field_70461_c;

        for (BlockPos targetPos : surroundTargets) {
            if (blocksPlacedThisTick >= blocksPerTick) break;

            // Check if the block is already filled or occupied
            if (!mc.field_71441_e.func_180495_p(targetPos).func_185904_a().func_76222_j()) {
                continue;
            }

            // Find a valid solid adjacent support block face to attach our block against
            BlockPos neighbor = null;
            EnumFacing side = null;

            for (EnumFacing facing : EnumFacing.values()) {
                BlockPos offsetPos = targetPos.func_177972_a(facing);
                if (!mc.field_71441_e.func_175623_d(offsetPos)) {
                    neighbor = offsetPos;
                    side = facing.func_176734_d();
                    break;
                }
            }

            // Fallback: If no neighbors exist, search directly beneath the target position (floor anchor)
            if (neighbor == null) {
                BlockPos below = targetPos.func_177977_b();
                if (!mc.field_71441_e.func_175623_d(below)) {
                    neighbor = below;
                    side = EnumFacing.UP;
                }
            }

            if (neighbor != null && side != null) {
                // 1. Silent Rotation alignment targeting the neighboring attachment vector face center
                if (strictRotations) {
                    lookAtBlockFace(neighbor, side);
                }

                // 2. Ghost hand hotbar swap packet sequence
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(obsidianSlot));

                // 3. Dispatch the placement use packet execution stream down the pipeline wire
                Vec3d hitVec = new Vec3d(neighbor).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(side.func_176730_m()).func_186678_a(0.5));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(
                        neighbor, side, EnumHand.MAIN_HAND, (float) hitVec.field_72450_a, (float) hitVec.field_72448_b, (float) hitVec.field_72449_c));
                mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);

                // 4. Return to original active inventory held asset index key item
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(currentSlot));

                blocksPlacedThisTick++;
            }
        }

        // If the module finished wrapping the entire protective cage, auto-toggle off to save processing cycles
        if (blocksPlacedThisTick == 0 && autoDisable) {
            this.setEnabled(false);
        }
    }

    private int findObsidianSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (!stack.func_190926_b() && stack.func_77973_b() instanceof ItemBlock) {
                if (((ItemBlock) stack.func_77973_b()).func_179223_d() == Blocks.field_150343_Z) {
                    return i;
                }
            }
        }
        return -1;
    }

    private void lookAtBlockFace(BlockPos pos, EnumFacing facing) {
        Vec3d hitVec = new Vec3d(pos).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(facing.func_176730_m()).func_186678_a(0.5));

        double diffX = hitVec.field_72450_a - mc.field_71439_g.field_70165_t;
        double diffY = hitVec.field_72448_b - (mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e());
        double diffZ = hitVec.field_72449_c - mc.field_71439_g.field_70161_v;
        double diffXZ = MathHelper.func_76133_a(diffX * diffX + diffZ * diffZ);

        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(Math.atan2(diffY, diffXZ) * 180.0 / Math.PI);

        float serverYaw = mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z);
        float serverPitch = mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A);
        serverPitch = MathHelper.func_76131_a(serverPitch, -90.0f, 90.0f);

        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(serverYaw, serverPitch, mc.field_71439_g.field_70122_E));
    }

    @Override
    protected void onUpdate() {}
}
