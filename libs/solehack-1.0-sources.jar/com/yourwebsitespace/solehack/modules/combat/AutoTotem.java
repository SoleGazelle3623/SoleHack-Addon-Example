package com.yourwebsitespace.solehack.modules.combat;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AutoTotem extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // Tracks remaining totems in your inventory
    public int totemsRemaining = 0;

    public AutoTotem() {
        super("AutoTotem", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            return;
        }

        // Safety: Do not shuffle slots around if viewing an inventory chest/container screen
        if (mc.field_71462_r instanceof GuiContainer) {
            return;
        }

        // Count current storage capacity metrics
        totemsRemaining = getTotemCount();

        // Check if offhand is already holding a totem
        if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
            return;
        }

        // Find a raw replacement slot mapping
        int totemSlot = findTotemSlot();
        if (totemSlot == -1) return;

        // Execute inventory fast-click packets to swap the item into offhand (Slot 45)
        // Step 1: Click the item inside the inventory to pick it up on the cursor
        mc.field_71442_b.func_187098_a(0, totemSlot, 0, ClickType.PICKUP, mc.field_71439_g);

        // Step 2: Click the offhand slot (slot 45) to place the totem there
        mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, mc.field_71439_g);

        // Step 3: Put whatever was originally in the offhand back into the vacant slot
        mc.field_71442_b.func_187098_a(0, totemSlot, 0, ClickType.PICKUP, mc.field_71439_g);
    }

    private int findTotemSlot() {
        // Iterate through standard player inventory spaces (excluding armor slots)
        for (int i = 9; i < 45; i++) {
            ItemStack stack = mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
            if (!stack.func_190926_b() && stack.func_77973_b() == Items.field_190929_cY) {
                return i;
            }
        }
        return -1;
    }

    private int getTotemCount() {
        int count = 0;
        for (int i = 0; i < 45; i++) {
            ItemStack stack = mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
            if (!stack.func_190926_b() && stack.func_77973_b() == Items.field_190929_cY) {
                count += stack.func_190916_E();
            }
        }
        if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
            count += mc.field_71439_g.func_184592_cb().func_190916_E();
        }
        return count;
    }

    @Override
    protected void onUpdate() {}
}
