package com.yourwebsitespace.solehack.modules.combat;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class CrystalAura extends Module {

    public static CrystalAura INSTANCE;
    private final Minecraft mc = Minecraft.func_71410_x();

    public double range = 5.0;
    public double wallsRange = 3.5;
    public boolean strictRotations = true;
    public boolean protocol13 = true;
    public boolean silentSwitch = true;

    // Delay configurations (in milliseconds)
    public int placeDelay = 0;
    public int breakDelay = 0;

    private long lastPlaceTime = 0;
    private long lastBreakTime = 0;

    private BlockPos renderPos = null;

    public CrystalAura() {
        super("CrystalAura", Category.COMBAT);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
        renderPos = null;
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        renderPos = null;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || event.phase != TickEvent.Phase.START) {
            return;
        }

        if (!this.isEnabled()) {
            renderPos = null;
            return;
        }

        EntityPlayer target = getClosestTarget();
        if (target == null) {
            renderPos = null;
            return;
        }

        // Single-tick double burst execution powered by Mixin prediction
        breakCrystals(target);
        placeCrystal(target);
    }

    private EntityPlayer getClosestTarget() {
        return mc.field_71441_e.field_73010_i.stream()
                .filter(player -> player != mc.field_71439_g && !player.field_70128_L && player.func_110143_aJ() > 0)
                .filter(player -> mc.field_71439_g.func_70032_d(player) <= range)
                .min(Comparator.comparingDouble(player -> mc.field_71439_g.func_70032_d(player)))
                .orElse(null);
    }

    private boolean breakCrystals(EntityPlayer target) {
        if (System.currentTimeMillis() - lastBreakTime < breakDelay) {
            return false;
        }

        List<EntityEnderCrystal> crystals = mc.field_71441_e.field_72996_f.stream()
                .filter(EntityEnderCrystal.class::isInstance)
                .map(EntityEnderCrystal.class::cast)
                .filter(crystalEntity -> {
                    double reach = mc.field_71439_g.func_70685_l(crystalEntity) ? range : wallsRange;
                    return mc.field_71439_g.func_70032_d(crystalEntity) <= reach;
                })
                .sorted(Comparator.comparingDouble(crystalEntity -> target.func_70032_d(crystalEntity)))
                .collect(Collectors.toList());

        if (crystals.isEmpty()) return false;

        EntityEnderCrystal crystal = crystals.get(0);

        if (strictRotations) {
            lookAtVector(crystal.func_174791_d());
        }

        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketUseEntity(crystal));
        mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);

        lastBreakTime = System.currentTimeMillis();
        return true;
    }

    private void placeCrystal(EntityPlayer target) {
        if (System.currentTimeMillis() - lastPlaceTime < placeDelay) {
            return;
        }

        int crystalSlot = findCrystalSlot();
        if (crystalSlot == -1) {
            renderPos = null;
            return;
        }

        BlockPos bestPos = null;
        double bestDist = range * range;

        int targetX = MathHelper.func_76128_c(target.field_70165_t);
        int targetY = MathHelper.func_76128_c(target.field_70163_u);
        int targetZ = MathHelper.func_76128_c(target.field_70161_v);

        for (int x = targetX - 3; x <= targetX + 3; x++) {
            for (int y = targetY - 2; y <= targetY + 2; y++) {
                for (int z = targetZ - 3; z <= targetZ + 3; z++) {
                    BlockPos pos = new BlockPos(x, y, z);

                    if (isValidBlock(pos)) {
                        double dist = mc.field_71439_g.func_174831_c(pos);

                        boolean canSee = mc.field_71441_e.func_147447_a(
                                new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v),
                                new Vec3d(pos.func_177958_n() + 0.5, pos.func_177956_o() + 1, pos.func_177952_p() + 0.5), false, true, false) == null;

                        if (!canSee && dist > (wallsRange * wallsRange)) continue;

                        if (dist <= bestDist) {
                            bestDist = dist;
                            bestPos = pos;
                        }
                    }
                }
            }
        }

        if (bestPos != null) {
            renderPos = bestPos;
            int oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;

            if (strictRotations) {
                lookAtVector(new Vec3d(bestPos.func_177958_n() + 0.5, bestPos.func_177956_o() + 1, bestPos.func_177952_p() + 0.5));
            }

            if (silentSwitch && crystalSlot != oldSlot) {
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(crystalSlot));
            } else {
                mc.field_71439_g.field_71071_by.field_70461_c = crystalSlot;
            }

            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItemOnBlock(
                    bestPos, EnumFacing.UP, EnumHand.MAIN_HAND, 0.5f, 1.0f, 0.5f));
            mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);

            if (silentSwitch && crystalSlot != oldSlot) {
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(oldSlot));
            }

            lastPlaceTime = System.currentTimeMillis();
        } else {
            renderPos = null;
        }
    }

    private boolean isValidBlock(BlockPos pos) {
        if (mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150343_Z &&
                mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150357_h) {
            return false;
        }

        BlockPos up1 = pos.func_177984_a();
        BlockPos up2 = pos.func_177981_b(2);

        if (protocol13) {
            if (!mc.field_71441_e.func_175623_d(up1)) return false;
        } else {
            if (!mc.field_71441_e.func_175623_d(up1) || !mc.field_71441_e.func_175623_d(up2)) return false;
        }

        double maxY = protocol13 ? 1.0 : 2.0;
        AxisAlignedBB box = new AxisAlignedBB(
                up1.func_177958_n(), up1.func_177956_o(), up1.func_177952_p(),
                up1.func_177958_n() + 1.0, up1.func_177956_o() + maxY, up1.func_177952_p() + 1.0
        );

        return mc.field_71441_e.func_72872_a(Entity.class, box).isEmpty();
    }

    private void lookAtVector(Vec3d targetVec) {
        double diffX = targetVec.field_72450_a - mc.field_71439_g.field_70165_t;
        double diffY = targetVec.field_72448_b - (mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e());
        double diffZ = targetVec.field_72449_c - mc.field_71439_g.field_70161_v;
        double diffXZ = MathHelper.func_76133_a(diffX * diffX + diffZ * diffZ);

        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(Math.atan2(diffY, diffXZ) * 180.0 / Math.PI);

        float serverYaw = mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z);
        float serverPitch = mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A);
        serverPitch = MathHelper.func_76131_a(serverPitch, -90.0f, 90.0f);

        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(serverYaw, serverPitch, mc.field_71439_g.field_70122_E));
    }

    private int findCrystalSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_185158_cP) {
                return i;
            }
        }
        return -1;
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || renderPos == null || !this.isEnabled()) {
            return;
        }

        double renderX = renderPos.func_177958_n() - mc.func_175598_ae().field_78730_l;
        double renderY = renderPos.func_177956_o() - mc.func_175598_ae().field_78731_m;
        double renderZ = renderPos.func_177952_p() - mc.func_175598_ae().field_78728_n;

        AxisAlignedBB bb = new AxisAlignedBB(renderX, renderY, renderZ, renderX + 1.0, renderY + 1.0, renderZ + 1.0);

        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(2.0f);

        RenderGlobal.func_189696_b(bb, 1.0f, 0.0f, 0.5f, 0.15f);
        RenderGlobal.func_189697_a(bb, 1.0f, 0.0f, 0.5f, 0.8f);

        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179126_j();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F(); // FIXED
    }

    @Override
    protected void onUpdate() {}
}