package com.yourwebsitespace.solehack.modules.misc;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

public class ShulkerPreview extends Module {

    public ShulkerPreview() {
        super("ShulkerPreview", Category.MISC);
    }

    @Override
    protected void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    protected void onUpdate() {

    }

    @Override
    protected void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onDrawForeground(GuiScreenEvent.DrawScreenEvent.Post event) {
        if (!(event.getGui() instanceof GuiContainer)) return;
        GuiContainer gui = (GuiContainer) event.getGui();

        Slot hovered = gui.getSlotUnderMouse();
        if (hovered == null || !hovered.func_75216_d()) return;

        ItemStack stack = hovered.func_75211_c();
        if (!isShulkerBox(stack)) return;

        List<ItemStack> contents = getShulkerContents(stack);
        if (contents.isEmpty()) return;

        drawPreview(gui, event.getMouseX(), event.getMouseY(), contents);
    }

    private boolean isShulkerBox(ItemStack stack) {
        if (stack.func_77973_b().getRegistryName() == null) return false;
        return stack.func_77973_b().getRegistryName().toString().contains("shulker_box");
    }

    private List<ItemStack> getShulkerContents(ItemStack stack) {
        List<ItemStack> items = new ArrayList<>();
        NBTTagCompound tag = stack.func_77978_p();
        if (tag == null || !tag.func_74764_b("BlockEntityTag")) return items;

        NBTTagCompound blockEntity = tag.func_74775_l("BlockEntityTag");
        if (!blockEntity.func_74764_b("Items")) return items;

        NBTTagList itemList = blockEntity.func_150295_c("Items", 10);
        for (int i = 0; i < itemList.func_74745_c(); i++) {
            ItemStack itemStack = new ItemStack(itemList.func_150305_b(i));
            if (!itemStack.func_190926_b()) {
                items.add(itemStack);
            }
        }
        return items;
    }

    private void drawPreview(GuiContainer gui, int mouseX, int mouseY, List<ItemStack> contents) {
        int cols = 9;
        int rows = (int) Math.ceil(contents.size() / (double) cols);
        int slotSize = 18;

        int width = cols * slotSize + 8;
        int height = rows * slotSize + 8;

        int x = mouseX + 12;
        int y = mouseY - height - 12;

        if (y < 0) y = mouseY + 12;
        if (x + width > gui.field_146294_l) x = gui.field_146294_l - width - 4;

        Minecraft mc = Minecraft.func_71410_x();

        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b(0, 0, 300); // draw above tooltips

        Gui.func_73734_a(x, y, x + width, y + height, 0xF0100010);

        RenderHelper.func_74520_c();
        for (int i = 0; i < contents.size(); i++) {
            int col = i % cols;
            int row = i / cols;
            int slotX = x + 4 + col * slotSize;
            int slotY = y + 4 + row * slotSize;

            mc.func_175599_af().func_180450_b(contents.get(i), slotX, slotY);
            mc.func_175599_af().func_180453_a(mc.field_71466_p, contents.get(i), slotX, slotY, null);
        }
        RenderHelper.func_74518_a();

        GlStateManager.func_179121_F();
    }
}