package com.yourwebsitespace.solehack.modules.misc;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;
import java.io.IOException;

@SuppressWarnings("unused") // 🌟 This annotation instantly removes the yellow "never used" warnings
public class ProxyConfigScreen extends GuiScreen {
    private final GuiScreen parentScreen;
    private final com.yourwebsitespace.solehack.modules.misc.Proxy proxyModule;

    private GuiTextField ipField;
    private GuiTextField portField;
    private GuiButton toggleButton;

    // The constructor that takes your parent screen and your custom Proxy module instance
    public ProxyConfigScreen(GuiScreen parentScreen, com.yourwebsitespace.solehack.modules.misc.Proxy proxyModule) {
        this.parentScreen = parentScreen;
        this.proxyModule = proxyModule;
    }

    @Override
    public void func_73866_w_() {
        Keyboard.enableRepeatEvents(true);
        this.field_146292_n.clear();

        int centerX = this.field_146294_l / 2;
        int centerY = this.field_146295_m / 2;

        // Input field for IP
        this.ipField = new GuiTextField(0, this.field_146289_q, centerX - 100, centerY - 40, 200, 20);
        this.ipField.func_146203_f(255);
        this.ipField.func_146195_b(true);
        this.ipField.func_146180_a(proxyModule.proxyIp);

        // Input field for Port
        this.portField = new GuiTextField(1, this.field_146289_q, centerX - 100, centerY, 200, 20);
        this.portField.func_146203_f(5);
        this.portField.func_146180_a(String.valueOf(proxyModule.proxyPort));

        // Interactive buttons
        this.toggleButton = new GuiButton(2, centerX - 100, centerY + 30, 200, 20, getToggleLabel());
        this.field_146292_n.add(this.toggleButton);
        this.field_146292_n.add(new GuiButton(3, centerX - 100, centerY + 55, 200, 20, "Done"));
    }

    private String getToggleLabel() {
        return "Status: " + (proxyModule.activeState ? "§aENABLED" : "§cDISABLED");
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();

        int centerX = this.field_146294_l / 2;
        int centerY = this.field_146295_m / 2;

        this.func_73732_a(this.field_146289_q, "SoleHack Proxy Configuration", centerX, centerY - 80, 0xFFFFFF);
        this.func_73731_b(this.field_146289_q, "Proxy IP / Hostname:", centerX - 100, centerY - 52, 0xA0A0A0);
        this.func_73731_b(this.field_146289_q, "Proxy Port:", centerX - 100, centerY - 12, 0xA0A0A0);

        this.ipField.func_146194_f();
        this.portField.func_146194_f();

        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        this.ipField.func_146201_a(typedChar, keyCode);
        this.portField.func_146201_a(typedChar, keyCode);

        // Tab swapping focus between fields
        if (keyCode == Keyboard.KEY_TAB) {
            if (this.ipField.func_146206_l()) {
                this.ipField.func_146195_b(false);
                this.portField.func_146195_b(true);
            } else {
                this.ipField.func_146195_b(true);
                this.portField.func_146195_b(false);
            }
        }

        // Enter key confirms changes
        if (keyCode == Keyboard.KEY_RETURN || keyCode == Keyboard.KEY_NUMPADENTER) {
            func_146284_a(this.field_146292_n.get(1));
        }

        super.func_73869_a(typedChar, keyCode);
    }

    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.func_73864_a(mouseX, mouseY, mouseButton);
        this.ipField.func_146192_a(mouseX, mouseY, mouseButton);
        this.portField.func_146192_a(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (!button.field_146124_l) return;

        if (button.field_146127_k == 2) {
            saveSettings();

            // Handles switching states using the custom variables in your Proxy module
            if (proxyModule.activeState) {
                proxyModule.onDisable();
            } else {
                proxyModule.onEnable();
            }

            this.toggleButton.field_146126_j = getToggleLabel();
        }
        else if (button.field_146127_k == 3) {
            saveSettings();
            this.field_146297_k.func_147108_a(this.parentScreen); // Returns back to the click GUI menu
        }
    }

    private void saveSettings() {
        String ip = this.ipField.func_146179_b().trim();
        int port;
        try {
            port = Integer.parseInt(this.portField.func_146179_b().trim());
        } catch (NumberFormatException e) {
            port = 9050;
        }
        proxyModule.setProxyConfig(ip, port);
    }

    @Override
    public void func_146281_b() {
        Keyboard.enableRepeatEvents(false);
    }
}
