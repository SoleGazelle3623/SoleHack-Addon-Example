package com.yourwebsitespace.solehack.modules.misc;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class WallHack extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // Configuration parameters
    public double trackingRange = 64.0; // Distance to search for player boxes

    public WallHack() {
        super("WallHack", Category.MISC);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null || !this.isEnabled()) {
            return;
        }

        // Initialize GL state matrix settings
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();

        // CRUCIAL WALLHACK SETTING: Disabling the depth buffer forces geometry to render on top of all solid blocks
        GlStateManager.func_179097_i();

        GlStateManager.func_179120_a(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(2.0f); // Width threshold of the box outline frames

        // Iterate through all loaded players inside the active chunk grid
        for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
            if (player == mc.field_71439_g || player.field_70128_L || player.func_110143_aJ() <= 0) {
                continue; // Skip ourselves and dead targets
            }

            if (mc.field_71439_g.func_70032_d(player) > trackingRange) {
                continue; // Skip players outside our configuration boundary limits
            }

            // Interpolate coordinates cleanly to prevent stuttering boxes when players move at high speeds
            double renderX = player.field_70142_S + (player.field_70165_t - player.field_70142_S) * event.getPartialTicks() - mc.func_175598_ae().field_78730_l;
            double renderY = player.field_70137_T + (player.field_70163_u - player.field_70137_T) * event.getPartialTicks() - mc.func_175598_ae().field_78731_m;
            double renderZ = player.field_70136_U + (player.field_70161_v - player.field_70136_U) * event.getPartialTicks() - mc.func_175598_ae().field_78728_n;

            // Generate an exact matching 3D bounding box layout around the player model size specifications
            double halfWidth = player.field_70130_N / 2.0;
            AxisAlignedBB bb = new AxisAlignedBB(
                    renderX - halfWidth, renderY, renderZ - halfWidth,
                    renderX + halfWidth, renderY + player.field_70131_O, renderZ + halfWidth
            );

            // Default Color: Soft Cyan/Blue for regular enemy players
            float r = 0.0f;
            float g = 0.7f;
            float b = 1.0f;

            // Optional structural hook layout for low-health targets (Turns red if below 5 hearts)
            if (player.func_110143_aJ() + player.func_110139_bj() <= 10.0f) {
                r = 1.0f; g = 0.2f; b = 0.2f;
            }

            // Render a clean translucent selection box fill and solid outline visible through any obstruction
            RenderGlobal.func_189696_b(bb, r, g, b, 0.12f);
            RenderGlobal.func_189697_a(bb, r, g, b, 0.8f);
        }

        // Return state machine indicators cleanly back to vanilla engine standards
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179126_j(); // Re-enable depth testing so standard blocks render properly again
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    @Override
    protected void onUpdate() {}
}
