package com.yourwebsitespace.solehack.modules.misc;

import com.yourwebsitespace.solehack.Category;
import com.yourwebsitespace.solehack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoEZ extends Module {

    private final Minecraft mc = Minecraft.func_71410_x();

    // Customization fields
    public String message = "You just got Nae Nae'd by SoleHack";
    public double trackingRange = 10.0;

    public AutoEZ() {
        super("AutoEZ", Category.MISC);
    }

    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        if (mc.field_71439_g == null || mc.field_71441_e == null) return;
        if (!this.isEnabled()) return;

        // Check if the entity that died is a player
        if (event.getEntityLiving() instanceof EntityPlayer) {
            EntityPlayer deadPlayer = (EntityPlayer) event.getEntityLiving();

            // Make sure it's not you
            if (deadPlayer == mc.field_71439_g) return;

            // Verify you were close enough
            if (mc.field_71439_g.func_70032_d(deadPlayer) <= trackingRange) {
                sendAutoEzMessage(deadPlayer.func_70005_c_());
            }
        }
    }

    private void sendAutoEzMessage(String playerName) {
        String finalMessage = message.replace("{player}", playerName);
        mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage(finalMessage));
    }

    @Override
    protected void onUpdate() {}
}