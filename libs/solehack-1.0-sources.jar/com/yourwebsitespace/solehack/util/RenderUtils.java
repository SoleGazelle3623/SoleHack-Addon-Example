package com.yourwebsitespace.solehack.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

import java.awt.Color;

public class RenderUtils {

    private static final Minecraft mc = Minecraft.func_71410_x();

    public static void startSmooth() {
        GlStateManager.func_179147_l();
        GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179141_d();
        GlStateManager.func_179090_x();
        GlStateManager.func_179103_j(GL11.GL_SMOOTH);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GlStateManager.func_179097_i();
        GlStateManager.func_179132_a(false);
    }

    public static void endSmooth() {
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
        GlStateManager.func_179103_j(GL11.GL_FLAT);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.func_179126_j();
        GlStateManager.func_179132_a(true);
    }

    public static void drawEntityBox(Entity entity, Color color, boolean filled) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);

        float alpha = filled ? 0.25f : 1.0f;
        GlStateManager.func_179131_c(color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f, alpha);

        double x = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * mc.func_184121_ak() - mc.func_175598_ae().field_78730_l;
        double y = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * mc.func_184121_ak() - mc.func_175598_ae().field_78731_m;
        double z = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * mc.func_184121_ak() - mc.func_175598_ae().field_78728_n;

        AxisAlignedBB bb = entity.func_174813_aQ().func_72321_a(0.1, 0.1, 0.1).func_72317_d(-entity.field_70165_t, -entity.field_70163_u, -entity.field_70161_v).func_72317_d(x, y, z);

        RenderGlobal.func_189697_a(bb, color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f, 1.0f);

        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179126_j();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }
}